"""推送消息模板 — YYZL v4

模板格式:
    🚨【信息未回复预警 - 商务】

    中心/公司:商务中心/领航公司
    人员/外事号昵称:陈新吉/悦悦-【官方收量】
    问题事项:长时间未查看消息1例

    未回复时长:30 分钟
    触发时间:2026-04-25 14:47 (柬时)
    监察人员: @maixiaomai1110 (麦小麦1)
"""
import os
import config
from datetime import datetime
try:
    import pytz
    BJ_TZ = pytz.timezone('Asia/Shanghai')
    KH_TZ = pytz.timezone('Asia/Phnom_Penh')
except ImportError:
    BJ_TZ = None
    KH_TZ = None


# 中心 → 群标题缩写
_CENTER_SHORT = {
    "商务中心": "商务",
    "渠道中心": "渠道",
    "运营中心": "运营",
    "恒丰公司": "恒丰",
    "恒丰中心": "恒丰",
}


def _center_short(center: str) -> str:
    if not center:
        return "未知"
    return _CENTER_SHORT.get(center, center.replace("中心", "").replace("公司", ""))


def _now_kh():
    if KH_TZ:
        return datetime.now(KH_TZ).strftime("%Y-%m-%d %H:%M")
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def _supervisor_label():
    """监察人员标签 - 「麦小麦1」"""
    explicit = os.getenv("SUPERVISOR_LABEL", "").strip()
    if explicit:
        return explicit
    operator = os.getenv("OPERATOR_NAME", "").strip()
    vps_num = os.getenv("VPS_NUM", "").strip()
    if operator and vps_num:
        return f"{operator}{vps_num}"
    vps_code = os.getenv("VPS_CODE", "").strip()
    if vps_code:
        import re
        m = re.search(r"(\D+?)-?(\d+)", vps_code)
        if m:
            return f"{m.group(1)}{m.group(2)}"
        return vps_code
    return "未知"


def _supervisor_at_tag() -> str:
    """监察人员 @username 部分,如 '@maixiaomai1110 (麦小麦1)'

    优先用 TG_USERNAME (本机 .env 写入), 没有就只显示文字标签
    """
    label = _supervisor_label()
    username = os.getenv("TG_USERNAME", "").strip().lstrip("@")
    if username:
        return f"@{username} ({label})"
    return label


def _format_center_company(center: str, company: str) -> str:
    c = center or "未知中心"
    co = company or "未知公司"
    return f"{c}/{co}"


def _format_person_peer(person: str, peer_name: str) -> str:
    p = person or "未指定"
    n = peer_name or "未知外事号"
    return f"{p}/{n}"


# ============================================================
# 1. 怠工预警 (推怠工群)
# ============================================================
def no_reply_alert(center, company, person, peer_name, opposite_name="", no_reply_minutes=None,
                   count=1, message_text="", **_kwargs):  # v1.1-bug4fix
    short = _center_short(center)
    cc = _format_center_company(center, company)
    pp = _format_person_peer(person, peer_name)
    if no_reply_minutes is None:
        no_reply_minutes = getattr(config, "NO_REPLY_MINUTES", 30)
    issue = f"长时间未查看消息{count}例"
    return (
        f"🚨【信息未回复预警 - {short}】\n"
        f"\n"
        f"中心/公司:{cc}\n"
        f"人员/外事号昵称:{pp}\n"
        f"广告主:{opposite_name or '无'}\n"
        f"问题事项:{issue}\n"
        f"未回复信息:{message_text or '(无)'}\n"  # v1.1-bug4fix
        f"\n"
        f"未回复时长:{no_reply_minutes} 分钟\n"
        f"触发时间:{_now_kh()} (柬时)\n"
        f"监察人员: {_supervisor_at_tag()}"
    )


# ============================================================
# 2. 风控预警 - 撤回 / 敏感词 (推风控群)
# ============================================================
RISK_RULES = {
    "deleted":   "对方撤回消息",
    "self_del":  "我方删除对话",
    "keyword":   "出现敏感词",
}


def risk_alert(rule, center, company, person, peer_name,
               extra_content="", keyword="", opposite_name=""):
    short = _center_short(center)
    cc = _format_center_company(center, company)
    pp = _format_person_peer(person, peer_name)
    desc = RISK_RULES.get(rule, rule)
    if rule == "keyword" and keyword:
        desc = f"出现敏感词「{keyword}」"

    lines = [
        f"🚨【风控预警 - {short}】",
        "",
        f"中心/公司:{cc}",
        f"人员/外事号昵称:{pp}",
        f"广告主:{opposite_name}" if opposite_name else "",
        f"风控:{desc}",
    ]
    if extra_content:
        c = extra_content if len(extra_content) <= 500 else extra_content[:500] + "..."
        lines.append(f"对话内容:{c}")
    lines += [
        "",
        f"监察人员: {_supervisor_at_tag()}",
    ]
    return "\n".join(lines)


# ============================================================
# 3. 档案预警 - 图片/语音/视频/文件/外链 (推档案群)
# ============================================================
ARCHIVE_RULES = {
    "photo":     "发送图片",
    "video":     "发送视频",
    "voice":     "发送语音",
    "file":      "发送文件",
    "link":      "发送外链",
}


def archive_alert(rule, center, company, person, peer_name, extra_content="", opposite_name=""):
    short = _center_short(center)
    cc = _format_center_company(center, company)
    pp = _format_person_peer(person, peer_name)
    desc = ARCHIVE_RULES.get(rule, rule)

    lines = [
        f"🚨【档案预警 - {short}】",
        "",
        f"中心/公司:{cc}",
        f"人员/外事号昵称:{pp}",
        f"档案:{desc}",
    ]
    if extra_content:
        c = extra_content if len(extra_content) <= 500 else extra_content[:500] + "..."
        lines.append(f"对话内容:{c}")
    lines += [
        "",
        f"监察人员: {_supervisor_at_tag()}",
    ]
    return "\n".join(lines)


# ============================================================
# 4. 旧 API 向后兼容
# ============================================================
def keyword_alert(company, operator, account_name, peer_name, keyword, message_text,
                  peer_username="", **_):
    center, comp = _split_center_company(company)
    return risk_alert(
        rule="keyword",
        center=center, company=comp,
        person=operator, peer_name=account_name,
        extra_content=message_text, keyword=keyword,
    )


def delete_alert(company, operator, account_name, peer_name, message_text="",
                 peer_username="", delete_time="", **_):
    center, comp = _split_center_company(company)
    return risk_alert(
        rule="deleted",
        center=center, company=comp,
        person=operator, peer_name=account_name,
        extra_content=message_text or "(消息内容未记录)",
    )


def _split_center_company(combined):
    if not combined:
        return "", ""
    s = combined.strip()
    if " / " in s:
        a, b = s.split(" / ", 1)
        return a.strip(), b.strip()
    if "/" in s:
        a, b = s.split("/", 1)
        return a.strip(), b.strip()
    return s, ""


# ============================================================
# 5. 日报
# ============================================================
def daily_report(report_date, record_time, chat_count,
                 no_reply_count, delete_count, keyword_count,
                 no_reply_detail=None, delete_detail=None):
    def _fmt(total, detail):
        if not detail:
            return f"{total}"
        return f"{total}  (已通过 {detail.get('approved', 0)} / 待审 {detail.get('pending', 0)} / 已拒 {detail.get('rejected', 0)})"
    return (
        f"【外事号监控总结】\n\n"
        f"统计日期: {report_date}\n"
        f"记录时间: {record_time}\n"
        f"监控聊天总数: {chat_count}\n"
        f"未回复数量: {_fmt(no_reply_count, no_reply_detail)}\n"
        f"信息删除数量: {_fmt(delete_count, delete_detail)}\n"
        f"关键词监听数量: {keyword_count}"
    )


# ============================================================
# 6. 会话被吊销/恢复
# ============================================================
def session_revoked_alert(phone, account_name, vps_label="", operator_name="", web_url=""):
    """v3.5: 会话吊销预警 - 加 VPS 标识/监察员/后台链接"""
    return (
        f"🚨 【TG 会话被吊销 / 可能被盗】\n\n"
        f"📍 VPS: {vps_label or '未命名'}\n"
        f"👤 监察员: {operator_name or '未指定'}\n\n"
        f"外事号: {account_name}\n"
        f"手机: {phone}\n\n"
        f"⚠️ 该账号 session 已失效, 可能原因:\n"
        f"  • 账号主人/攻击者撤销了本设备 session\n"
        f"  • TG 官方风控\n"
        f"  • 账号被注销\n\n"
        f"🔧 处理步骤:\n"
        f"  1. 打开后台: {web_url or '请咨询管理员获取后台地址'}\n"
        f"  2. 账号管理 → 找到该账号 → 重新登录\n"
        f"  3. 登录成功会自动推「✅ 会话已恢复」"
    )


def session_restored_alert(phone, account_name, vps_label="", operator_name="", web_url=""):
    """v3.5: 会话恢复预警 - 加 VPS 标识/监察员"""
    return (
        f"✅ 【TG 会话已恢复】\n\n"
        f"📍 VPS: {vps_label or '未命名'}\n"
        f"👤 监察员: {operator_name or '未指定'}\n\n"
        f"外事号: {account_name}\n"
        f"手机: {phone}\n\n"
        f"账号已重新登录成功, 监控继续运行。"
    )
