"""TG Bot — 预警推送 + 审核按钮"""
import json
import logging
import asyncio
import os
from aiogram import Bot, Dispatcher, F
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery

import config
import database as db
import templates

# YYZL v2.11: 中心智能分发
try:
    from center_router import route_to_group
except ImportError:
    route_to_group = None

logger = logging.getLogger(__name__)


def _suffix_for_rule(rule: str) -> str:
    """转发媒体时的临时文件扩展名"""
    return {
        "photo": ".jpg",
        "video": ".mp4",
        "voice": ".ogg",
        "file":  ".bin",
    }.get(rule, ".bin")


class AlertBot:
    def __init__(self, sheets_writer=None):
        self.sheets = sheets_writer
        if not config.BOT_TOKEN:
            logger.warning("BOT_TOKEN 未设置，Bot 功能暂时关闭")
            self.bot = None
            self.dp = None
            return

        self.bot = Bot(token=config.BOT_TOKEN)
        self.dp = Dispatcher()
        self._register_handlers()


    def _get_group_id_for_peer(self, peer, kind: str = "no_reply", account_id=None):
        """v4 YYZL: 根据外事号所属中心,智能路由到对应群

        参数:
            peer: peer 字典或 sqlite3.Row
            kind: 'no_reply' (怠工) / 'risk' (风控) / 'archive' (档案)
            account_id: 外事号 ID,用于反查 center
        """
        # === v4.2 修复: 绕过 center_router,直接读 .env 环境变量 ===
        try:
            import os
            import database as db
            if account_id:
                row = db.get_conn().execute(
                    "SELECT center FROM accounts WHERE id=?", (account_id,)
                ).fetchone()
                if row:
                    center_zh = row["center"] if hasattr(row, "keys") else row[0]
                    if center_zh:
                        # 中心中文名 -> 英文 key
                        center_map = {
                            "商务中心": "SHANGWU",
                            "渠道中心": "QUDAO",
                            "运营中心": "YUNYING",
                            "恒丰公司": "HENGFENG",
                            "恒丰中心": "HENGFENG",
                        }
                        center_key = center_map.get(center_zh)
                        if center_key:
                            # kind -> .env 变量前缀
                            prefix_map = {
                                "no_reply": "ALERT_GROUP_",
                                "risk": "ALERT_RISK_GROUP_",
                                "archive": "ALERT_ARCHIVE_GROUP_",
                            }
                            prefix = prefix_map.get(kind, "ALERT_GROUP_")
                            env_var = f"{prefix}{center_key}"
                            gid_str = os.environ.get(env_var, "").strip()
                            if gid_str:
                                try:
                                    gid = int(gid_str)
                                    logger.info(f"[v4.2 路由] center={center_zh} kind={kind} env={env_var} -> {gid}")
                                    return gid
                                except ValueError:
                                    logger.warning(f"[v4.2 路由] env={env_var}={gid_str} 不是合法整数")
                            else:
                                logger.warning(f"[v4.2 路由] env={env_var} 未配置")
                        else:
                            logger.warning(f"[v4.2 路由] center={center_zh} 没有英文 key 映射")
        except Exception as e:
            logger.warning(f"[v4.2 路由] account_id={account_id} 反查失败: {e}")

        # === 兜底: 用 peer_name 路由(老 v3 逻辑)===
        try:
            if route_to_group:
                peer_name = ""
                try:
                    peer_name = peer.get("name", "") if hasattr(peer, "get") else peer["name"]
                except Exception:
                    peer_name = ""
                if peer_name:
                    group_id, _info = route_to_group(peer_name, kind=kind)
                    if group_id:
                        return group_id
        except Exception as e:
            logger.warning(f"[中心路由] 失败,使用默认群: {e}")
        return config.ALERT_GROUP_ID

    def _get_peer_routing_info(self, peer):
        """v4.3: 通过 peer.account_id 从 accounts 表拿归属信息"""
        try:
            import database as _db
            account_id = None
            try:
                account_id = peer.get('account_id') if hasattr(peer, 'get') else peer['account_id']
            except Exception:
                account_id = None
            if account_id:
                row = _db.get_conn().execute(
                    'SELECT center, company_brand, person, operator FROM accounts WHERE id=?',
                    (account_id,)
                ).fetchone()
                if row:
                    d = dict(row) if hasattr(row, 'keys') else {}
                    return {
                        '中心': d.get('center') or '',
                        '公司': d.get('company_brand') or '',
                        '花名': d.get('person') or d.get('operator') or '',
                        '监察员': '',
                        'matched': True,
                    }
        except Exception as e:
            logger.warning(f'[v4.3 中心路由 info] 失败: {e}')
        return {'中心': '', '公司': '', '花名': '', '监察员': '', 'matched': False}


    def _has_any_alert_group(self):
        """v4: 任意一个中心群配了就算可推送"""
        if config.ALERT_GROUP_ID:
            return True
        try:
            from center_router import get_center_groups
            for kind in ("no_reply", "risk", "archive"):
                for gid in get_center_groups(kind=kind).values():
                    if gid:
                        return True
        except Exception:
            pass
        return False

    def _register_handlers(self):
        @self.dp.message(F.text == "/start")
        async def on_start(message):
            await message.reply(
                "👋 这是 TG 监控的预警 Bot。\n"
                "如果你要绑定账号做密码找回,请在网页设置页获取绑定码,\n"
                "然后发 /bind BIND-XXXXXX"
            )

        @self.dp.message(F.text.startswith("/bind"))
        async def on_bind(message):
            if message.chat.type != "private":
                await message.reply("请私聊我发送此指令。")
                return
            parts = message.text.strip().split(maxsplit=1)
            if len(parts) != 2:
                await message.reply("用法: /bind BIND-XXXXXX")
                return
            code = parts[1].strip().upper()
            import auth_reset
            tg_user_id = message.from_user.id
            tg_username = (message.from_user.username
                           or message.from_user.full_name
                           or str(tg_user_id))
            bound_user = auth_reset.try_complete_bind(code, tg_user_id, tg_username)
            if bound_user:
                await message.reply(
                    f"✅ 已绑定到帐号 {bound_user}\n"
                    "以后忘记密码可在登入页点「忘记密码」通过我私信收到验证码。"
                )
            else:
                await message.reply("❌ 绑定码无效或已过期。请回网页刷新获取新绑定码。")

        @self.dp.message(F.text == "/sync_daily")
        async def on_sync_daily(message):
            """手动触发每日数据写入 - v3.1 调试版
            权限: 仅群管理员可触发
            """
            # 详细日志,方便排查
            chat_id = message.chat.id
            chat_type = str(message.chat.type)
            user_id = message.from_user.id
            logger.info(f"[/sync_daily] 收到命令 chat_id={chat_id} type={chat_type} user_id={user_id}")
            # 1. 私聊不响应,但其他都响应(先放宽,确认能跑通再收紧)
            if "private" in chat_type.lower():
                logger.info("[/sync_daily] 私聊,跳过")
                return
            # 2. 检查发命令的人是否是群管理员
            try:
                member = await self.bot.get_chat_member(chat_id, user_id)
                logger.info(f"[/sync_daily] 用户角色: {member.status}")
                if str(member.status) not in ("ChatMemberStatus.CREATOR", "ChatMemberStatus.ADMINISTRATOR", "creator", "administrator"):
                    await message.reply(f"❌ 仅群管理员可触发 (你的角色: {member.status})")
                    return
            except Exception as e:
                logger.error(f"[/sync_daily] 权限检查失败: {e}", exc_info=True)
                await message.reply(f"❌ 权限检查失败: {e}")
                return
            # 3. 从 config 读取(不用 os.environ)
            try:
                import config
                sheet_id = getattr(config, "DAILY_SHEET_ID", "") or ""
                sheet_gid = getattr(config, "DAILY_SHEET_GID", "") or ""
            except Exception as e:
                await message.reply(f"❌ 读取配置失败: {e}")
                return
            if not sheet_id or not sheet_gid:
                await message.reply(f"❌ 配置缺失: SHEET_ID={bool(sheet_id)} GID={bool(sheet_gid)}")
                return
            # 4. 触发同步
            await message.reply("⏳ 正在同步每日数据,请稍候...")
            try:
                from daily_data_writer import run_daily_sync
                success, msg = run_daily_sync(sheet_id, sheet_gid)
                if success:
                    await message.reply(f"✅ 同步完成: {msg}")
                else:
                    await message.reply(f"⚠️ 同步未完成: {msg}")
            except Exception as e:
                logger.error(f"[/sync_daily] 同步异常", exc_info=True)
                await message.reply(f"❌ 同步异常: {e}")

    async def send_keyword_alert(self, account_id, peer, keyword, text):
        """发送敏感词预警 — v3 推风控群"""
        if not self.bot or not self._has_any_alert_group():
            return
        if db.has_alert_today("keyword", peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        # v4.4: peer_name=外事号TG昵称(account.name), opposite_name=对方名字(peer.name)
        opposite_name = peer["name"] if "name" in peer.keys() else ""
        try:
            peer_name = account["name"] if account and "name" in account.keys() else ""
        except Exception:
            peer_name = ""
        if not peer_name:
            peer_name = opposite_name

        msg = templates.risk_alert(
            rule="keyword",
            center=center,
            company=company,
            person=person,
            peer_name=peer_name,
            extra_content=text,
            keyword=keyword,
        )
        try:
            config.reload_if_env_changed()
            if config.ALERT_KEYWORD_ENABLED:
                _gid = self._get_group_id_for_peer(peer, kind="risk", account_id=account_id)
                await self.bot.send_message(_gid, msg)
            else:
                logger.info("[ALERT_KEYWORD_DISABLED] 跳过关键词推送 peer=%s keyword=%s (Sheet 仍写入)", peer["id"], keyword)
            # 写入关键词监听分表
            if self.sheets:
                for attempt in range(3):
                    try:
                        with self.sheets._write_lock:
                            ws = self.sheets.spreadsheet.worksheet("关键词监听")
                            self.sheets._rate_limit()
                            ws.append_row([
                                account["company"], account["operator"], account["name"],
                                peer["name"], keyword, text, db.now_bj()
                            ])
                        break
                    except Exception as e2:
                        logger.error("写入关键词分表失败 (尝试 %d/3): %s", attempt + 1, e2)
                        if attempt < 2:
                            import time; time.sleep(2)
            db.insert_alert("keyword", account_id, peer["id"], message_text=f"[{keyword}] {text}")
        except Exception as e:
            logger.error("发送关键词预警失败: %s", e)

    async def send_no_reply_alert(self, account_id, peer, message_text, msg_id):
        """发送怠工/未回复预警(每个广告主每天只推一次)— v3 新格式"""
        if not self.bot or not self._has_any_alert_group():
            return
        if db.has_alert_today("no_reply", peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        # 创建预警记录
        alert_id = db.insert_alert(
            alert_type="no_reply",
            account_id=account_id,
            peer_id=peer["id"],
            msg_id=msg_id,
            message_text=message_text,
        )

        # v3: 从 Sheet 路由信息拿中心/公司/花名(优先于 account 表)
        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        # v4.4 (send_risk_alert): 加 opposite_name + peer_name 改成 account.name
        opposite_name = peer["name"] if "name" in peer.keys() else ""
        try:
            peer_name = account["name"] if account and "name" in account.keys() else ""
        except Exception:
            peer_name = ""
        if not peer_name:
            peer_name = opposite_name

        msg = templates.no_reply_alert(
            center=center,
            company=company,
            person=person,
            peer_name=peer_name,
            no_reply_minutes=config.NO_REPLY_MINUTES,
            count=1,
                opposite_name=opposite_name,
                message_text=message_text,  # v1.1-bug4fix
        )
        # 推送总开关检查
        config.reload_if_env_changed()
        if not config.ALERT_NO_REPLY_ENABLED:
            logger.info("[ALERT_NO_REPLY_DISABLED] 跳过未回复推送 peer=%s (alerts 已记录)", peer["id"])
            return
        try:
            _gid = self._get_group_id_for_peer(peer, kind="no_reply", account_id=account_id)
            sent = await self.bot.send_message(
                _gid, msg,
            )
            db.update_alert_bot_msg(alert_id, sent.message_id)
        except Exception as e:
            logger.error("发送未回复预警失败: %s", e)

    async def send_delete_alert(self, account_id, peer, message_text, msg_id,
                                direction: str = ""):
        """发送删除消息预警 — v3 推风控群
        
        参数:
            direction: 'A' = 外事号自己发的(被自己删 → 我方删除)
                       'B' = 对方发的(被对方撤回 → 对方撤回消息)
                       ''  = 兼容旧调用,默认按对方撤回
        """
        if not self.bot or not self._has_any_alert_group():
            return
        if db.has_alert_today("deleted", peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        alert_id = db.insert_alert(
            alert_type="deleted",
            account_id=account_id,
            peer_id=peer["id"],
            msg_id=msg_id,
            message_text=message_text,
        )

        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        # v4.4 (send_risk_alert): 加 opposite_name + peer_name 改成 account.name
        opposite_name = peer["name"] if "name" in peer.keys() else ""
        try:
            peer_name = account["name"] if account and "name" in account.keys() else ""
        except Exception:
            peer_name = ""
        if not peer_name:
            peer_name = opposite_name

        # v3: 根据 direction 选 rule
        if direction == "A":
            rule = "self_del"   # 我方删除对话
        else:
            rule = "deleted"    # 对方撤回消息

        msg = templates.risk_alert(
            rule=rule,
            center=center,
            company=company,
            person=person,
            peer_name=peer_name,
            extra_content=message_text or "",
        )
        config.reload_if_env_changed()
        if not config.ALERT_DELETE_ENABLED:
            logger.info("[ALERT_DELETE_DISABLED] 跳过删除推送 peer=%s (alerts 已记录)", peer["id"])
            return
        try:
            _gid = self._get_group_id_for_peer(peer, kind="risk", account_id=account_id)
            sent = await self.bot.send_message(
                _gid, msg,
            )
            db.update_alert_bot_msg(alert_id, sent.message_id)
        except Exception as e:
            logger.error("发送删除预警失败: %s", e)

    async def send_risk_alert(self, account_id, peer, rule: str, msg_obj=None,
                              text="", keyword=""):
        """v4 通用风控/档案预警 — 按 rule 路由到 风控群 或 档案群

        路由规则:
            - keyword (敏感词)            → 风控群 (RISK)
            - self_del (我方删除)         → 风控群 (RISK)
            - deleted (对方撤回)          → 风控群 (RISK)
            - photo/video/voice/file/link → 档案群 (ARCHIVE)
        """
        if not self.bot or not self._has_any_alert_group():
            return

        # 决定路由类别
        if rule in ("keyword", "self_del", "deleted"):
            route_kind = "risk"
        elif rule in ("photo", "video", "voice", "file", "link"):
            route_kind = "archive"
        else:
            logger.warning("[risk-%s] 未知规则,忽略", rule)
            return

        # 同 peer + 同 rule 当天只推一次
        dedupe_key = f"risk_{rule}"
        if db.has_alert_today(dedupe_key, peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        alert_id = db.insert_alert(
            alert_type=dedupe_key,
            account_id=account_id,
            peer_id=peer["id"],
            msg_id=getattr(msg_obj, "id", 0) if msg_obj else 0,
            message_text=(text or keyword or rule)[:500],
        )

        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        # v4.4 (send_risk_alert): 加 opposite_name + peer_name 改成 account.name
        opposite_name = peer["name"] if "name" in peer.keys() else ""
        try:
            peer_name = account["name"] if account and "name" in account.keys() else ""
        except Exception:
            peer_name = ""
        if not peer_name:
            peer_name = opposite_name

        # 用对应的模板函数
        if route_kind == "risk":
            print(f"📤 [DEBUG] 准备渲染 risk_alert 模板: rule={rule}, center={center}, company={company}, person={person}, peer_name={peer_name}")
            msg = templates.risk_alert(
                rule=rule, center=center, company=company,
                person=person, peer_name=peer_name,
                extra_content=text or "", keyword=keyword,
                opposite_name=opposite_name,
            )
        else:  # archive
            msg = templates.archive_alert(
                rule=rule, center=center, company=company,
                person=person, peer_name=peer_name,
                extra_content=text or "",
                opposite_name=opposite_name,
            )

        # 检查总开关
        config.reload_if_env_changed()
        if rule == "keyword" and not config.ALERT_KEYWORD_ENABLED:
            logger.info("[ALERT_KEYWORD_DISABLED] 跳过风控-敏感词推送")
            return
        risk_enabled = os.environ.get("ALERT_RISK_ENABLED", "true").strip().lower()
        archive_enabled = os.environ.get("ALERT_ARCHIVE_ENABLED", "true").strip().lower()
        if route_kind == "risk" and risk_enabled in ("false", "0", "no"):
            logger.info("[ALERT_RISK_DISABLED] 跳过风控-%s 推送", rule)
            return
        if route_kind == "archive" and archive_enabled in ("false", "0", "no"):
            logger.info("[ALERT_ARCHIVE_DISABLED] 跳过档案-%s 推送", rule)
            return

        try:
            _gid = self._get_group_id_for_peer(peer, kind=route_kind, account_id=account_id)
            # v4.6: archive + 媒体 = caption 一条发;否则纯文字
            if route_kind == "archive" and msg_obj is not None and rule in ("photo", "video", "voice", "file"):
                try:
                    await self._forward_media_via_download(_gid, msg_obj, rule, caption=msg)
                    db.update_alert_bot_msg(alert_id, 0)
                except Exception as e:
                    logger.warning("[archive-%s] caption 转发失败,退回纯文字: %s", rule, e)
                    sent = await self.bot.send_message(_gid, msg)
                    db.update_alert_bot_msg(alert_id, sent.message_id)
            else:
                sent = await self.bot.send_message(_gid, msg)
                db.update_alert_bot_msg(alert_id, sent.message_id)

                if msg_obj is not None and rule in ("photo", "video", "voice", "file"):
                    try:
                        await self._forward_media_via_download(_gid, msg_obj, rule)
                    except Exception as e:
                        logger.warning("[%s-%s] 转发媒体失败: %s", route_kind, rule, e)
        except Exception as e:
            logger.error("[%s-%s] 发送预警失败: %s", route_kind, rule, e)

        # ===== v1.1 Bug 1 fix: write to Sheet audit tab =====
        if self.sheets and rule in ("keyword", "deleted", "self_del"):
            try:
                tab_name = "关键词监听" if rule == "keyword" else "信息删除预警"
                if rule == "keyword":
                    row_data = [
                        db.now_bj(), center, company, person,
                        peer_name, opposite_name,
                        keyword or "", text or ""
                    ]
                else:
                    row_data = [
                        db.now_bj(), center, company, person,
                        peer_name, opposite_name,
                        text or "", ""
                    ]
                for attempt in range(3):
                    try:
                        with self.sheets._write_lock:
                            ws = self.sheets.spreadsheet.worksheet(tab_name)
                            self.sheets._rate_limit()
                            ws.append_row(row_data)
                        logger.info("[v1.1-bugfix] Sheet write OK: tab=%s keyword=%s", tab_name, keyword)
                        break
                    except Exception as e2:
                        logger.error("[v1.1-bugfix] Sheet write FAIL tab=%s attempt=%d/3: %s", tab_name, attempt + 1, e2)
                        if attempt < 2:
                            import time
                            time.sleep(2)
            except Exception as e_outer:
                logger.error("[v1.1-bugfix] Sheet logic exception: %s", e_outer)
        # ===== fix end =====

    async def _forward_media_via_download(self, group_id: int, msg_obj, rule: str, caption: str = None):
        """把 Telethon Message 的媒体下载到本地,再用 aiogram 上传到群。

        注意:msg_obj 是 Telethon Message,client 是 listener 那边的 TelegramClient,
        我们从 msg_obj.client 拿。
        """
        import tempfile
        from aiogram.types import FSInputFile
        client = getattr(msg_obj, "_client", None) or getattr(msg_obj, "client", None)
        if client is None:
            logger.warning("[forward] msg_obj 无 client,跳过")
            return
        # 下载到临时文件
        with tempfile.NamedTemporaryFile(delete=False, suffix=_suffix_for_rule(rule)) as tmp:
            tmp_path = tmp.name
        try:
            await client.download_media(msg_obj, file=tmp_path)
            f = FSInputFile(tmp_path)
            if rule == "photo":
                await self.bot.send_photo(group_id, photo=f, caption=caption)
            elif rule == "video":
                await self.bot.send_video(group_id, video=f, caption=caption)
            elif rule == "voice":
                await self.bot.send_voice(group_id, voice=f, caption=caption)
            elif rule == "file":
                await self.bot.send_document(group_id, document=f, caption=caption)
        finally:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass

    async def send_daily_report(self):
        """发送每日总结"""
        if not self.bot or not config.ALERT_GROUP_ID:
            return
        # v2.6.2: 日报独立开关
        config.reload_if_env_changed()
        if not config.DAILY_REPORT_ENABLED:
            logger.info("[DAILY_REPORT_DISABLED] 跳过日报推送")
            return

        from database import TZ_BJ
        from datetime import datetime

        now = datetime.now(TZ_BJ).strftime("%Y-%m-%d %H:%M:%S")

        # 统计昨天的数据（00:00 发送时统计前一天）
        from datetime import timedelta
        yesterday = (datetime.now(TZ_BJ) - timedelta(days=1)).strftime("%Y-%m-%d")
        conn = db.get_conn()

        chat_count = conn.execute(
            "SELECT COUNT(DISTINCT peer_id) FROM messages WHERE timestamp LIKE ?",
            (f"{yesterday}%",)
        ).fetchone()[0]

        def _status_breakdown(type_name):
            rows = conn.execute(
                "SELECT status, COUNT(*) FROM alerts WHERE type=? AND created_at LIKE ? GROUP BY status",
                (type_name, f"{yesterday}%")
            ).fetchall()
            bucket = {"approved": 0, "pending": 0, "rejected": 0}
            for status, cnt in rows:
                if status in bucket:
                    bucket[status] = cnt
            return bucket

        no_reply_detail = _status_breakdown("no_reply")
        no_reply = sum(no_reply_detail.values())

        delete_detail = _status_breakdown("deleted")
        deleted = sum(delete_detail.values())

        keyword_count = conn.execute(
            "SELECT COUNT(*) FROM alerts WHERE type='keyword' AND created_at LIKE ?",
            (f"{yesterday}%",)
        ).fetchone()[0]

        msg = templates.daily_report(
            yesterday, now, chat_count, no_reply, deleted, keyword_count,
            no_reply_detail=no_reply_detail, delete_detail=delete_detail,
        )
        try:
            await self.bot.send_message(config.ALERT_GROUP_ID, msg)
            logger.info("日报已推送")
        except Exception as e:
            logger.error("发送日报失败: %s", e)

    async def send_session_alert(self, kind: str, phone: str, account_id: int = 0, account_name: str = ""):
        """v3.5 升级: 推送 session 吊销/恢复预警 — 中心路由 + 全推兜底
        - 旧版依赖 ALERT_GROUP_ID,但 .env 没配该字段 → 永远不推送
        - 新版按账号归属中心走 ALERT_GROUP_<XXXX> 怠工群; 账号未归属时 fallback 推所有 4 个怠工群
        - 模板加 VPS_LABEL/OPERATOR_NAME/web_url, 让监察员一眼看出哪台 VPS / 怎么处理
        """
        if not self.bot:
            logger.warning("[session_%s] bot 未配置,跳过 phone=%s", kind, phone)
            return
        try:
            config.reload_if_env_changed()
            # 1. 取 VPS 标识 + Web 后台链接
            vps_label = (config.VPS_LABEL or "未命名 VPS").strip()
            operator = (config.OPERATOR_NAME or "未指定").strip()
            web_host = self._get_web_host()
            web_url = f"http://{web_host}:{config.WEB_PORT}"
            # 2. 渲染模板
            if kind == "revoked":
                msg = templates.session_revoked_alert(phone, account_name, vps_label, operator, web_url)
                alert_type = "session_revoked"
            elif kind == "restored":
                msg = templates.session_restored_alert(phone, account_name, vps_label, operator, web_url)
                alert_type = "session_restored"
            else:
                logger.warning("[session_alert] 未知 kind=%s", kind)
                return
            # 3. DB 写表 (审计留痕,不受任何开关影响)
            try:
                if account_id:
                    db.insert_alert(alert_type, account_id, peer_id=None,
                                    message_text=f"[{phone}] {account_name}")
            except Exception as e:
                logger.warning("[session_%s] insert_alert 失败: %s", kind, e)
            # 4. 决定推送目标 — 优先按账号归属中心路由
            target_groups = []
            if account_id:
                try:
                    row = db.get_conn().execute(
                        "SELECT center FROM accounts WHERE id=?", (account_id,)
                    ).fetchone()
                    center_zh = ""
                    if row:
                        center_zh = (row["center"] or "").strip()
                    if center_zh:
                        from center_router import get_center_groups
                        groups_map = get_center_groups(kind="no_reply")
                        gid = groups_map.get(center_zh, 0)
                        if gid:
                            target_groups.append(gid)
                            logger.info("[session_%s] 账号「%s」归属「%s」 → 怠工群 %s",
                                        kind, account_name, center_zh, gid)
                        else:
                            logger.warning("[session_%s] 账号「%s」归属「%s」, 但该中心怠工群未配",
                                           kind, account_name, center_zh)
                    else:
                        logger.info("[session_%s] 账号「%s」未归属任何中心", kind, account_name)
                except Exception as e:
                    logger.warning("[session_%s] 查归属中心失败: %s", kind, e)
            # 5. 兜底:推所有怠工群 (账号未归属/中心未配 时)
            if not target_groups:
                try:
                    from center_router import get_center_groups
                    target_groups = [gid for gid in get_center_groups(kind="no_reply").values() if gid]
                    if target_groups:
                        logger.info("[session_%s] 兜底:推所有 %d 个怠工群", kind, len(target_groups))
                except Exception as e:
                    logger.error("[session_%s] 取怠工群列表失败: %s", kind, e)
            if not target_groups:
                logger.warning("[session_%s] 无任何怠工群可推, 跳过 phone=%s", kind, phone)
                return
            # 6. 真正推送 (去重)
            sent = set()
            ok = 0
            for gid in target_groups:
                if gid in sent:
                    continue
                sent.add(gid)
                try:
                    await self.bot.send_message(gid, msg)
                    ok += 1
                except Exception as e:
                    logger.error("[session_%s] 推 group=%s 失败: %s", kind, gid, e)
            logger.info("[session_%s] 完成 phone=%s, 推 %d/%d 个群", kind, phone, ok, len(sent))
        except Exception as e:
            logger.error("[session_%s] 总失败 phone=%s: %s", kind, phone, e)

    def _get_web_host(self):
        """取 Web 后台主机名/IP — 优先 .env 配的 EXTERNAL_IP, 没配则尝试 detect"""
        if config.EXTERNAL_IP:
            return config.EXTERNAL_IP
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            # 容器内多半是 172.x.x.x 私网,实际不可达,但聊胜于无 (用户可改 .env 修)
            return ip
        except Exception:
            return "your-vps-ip"

    async def send_update_notice(self, state: dict):
        """v2.9.0: 发现 GitHub 有新版 → 推送到预警群(同版本只推一次,update_checker 控制去重)"""
        if not self.bot or not config.ALERT_GROUP_ID:
            return

        new_commits = state.get("new_commits", [])
        latest_title = state.get("latest_user_title") or "📦 有新版本可升级"
        latest_body = state.get("latest_user_body") or ""

        company = getattr(config, "COMPANY_NAME", "")
        company_display = getattr(config, "COMPANY_DISPLAY", company)

        lines = [f"<b>{latest_title}</b>", "", f"部门:{company_display}"]
        if latest_body:
            lines.append("")
            lines.append(latest_body)

        # 如果中间跨了多个版本,把每个版本的白话也列出来
        if len(new_commits) > 1:
            lines.append("")
            lines.append(f"<b>本次更新涵盖 {len(new_commits)} 个版本:</b>")
            for c in new_commits[-6:]:
                t = c.get("user_title", "") or "更新"
                b = c.get("user_body", "")
                lines.append(f"  {t}")
                if b:
                    lines.append(f"    {b}")
            if len(new_commits) > 6:
                lines.append(f"  ...(还有 {len(new_commits)-6} 个,登入管理页看完整列表)")

        lines.append("")
        lines.append("<b>如何升级</b>(复制这行到服务器跑):")
        lines.append(f"<code>cd /root/tg-monitor-{company} && bash update.sh</code>")
        lines.append("")
        lines.append("✓ 有回滚保护,万一有问题会自动退回旧版")
        lines.append("✓ 升级期间网页会短暂刷新,大约 30 秒恢复")

        msg = "\n".join(lines)
        try:
            await self.bot.send_message(
                config.ALERT_GROUP_ID, msg,
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            _short = state.get("latest_short", "")
            logger.info(f"版本更新通知已推送: {_short}")
        except Exception as e:
            logger.error(f"版本更新通知推送失败: {e}")

    async def start(self):
        """启动 Bot 轮询"""
        if not self.dp:
            return
        logger.info("Bot 启动...")
        await self.dp.start_polling(self.bot)
