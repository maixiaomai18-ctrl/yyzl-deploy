"""
每日数据表同步模块
读「每日数据」Google Sheet 的 4 个监察员 Tab，建立外事号映射
"""
import json
import logging
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)

# 「每日数据」表 ID（从 .env 读，允许覆盖）
import os
DAILY_SHEET_ID = os.environ.get(
    "DAILY_SHEET_ID",
    "1Mpgh_MLhGtA0HlWqlRK1Vj7ydtkMMJ2_TFEpaYl8at0"
)

# 4 个监察员 Tab 名（顺序不重要）
SUPERVISORS = ["麦小麦", "季霖", "吴苍河", "陈家碧"]

# 本地缓存路径
BASE_DIR = Path(__file__).parent
CACHE_PATH = BASE_DIR / "data" / "daily_sheet_cache.json"


def sync_from_sheet(gc):
    """
    从 Google Sheet 读取 4 个监察员 Tab，建立映射表
    
    参数:
        gc: gspread 客户端（已授权）
    
    返回:
        dict: {外事号昵称: {中心, 公司, 花名, 监察员}}
    """
    mapping = {}
    stats = {s: 0 for s in SUPERVISORS}
    centers = {"商务中心": 0, "渠道中心": 0, "运营中心": 0, "恒丰公司": 0, "其他": 0}
    
    try:
        spreadsheet = gc.open_by_key(DAILY_SHEET_ID)
    except Exception as e:
        logger.error(f"打不开「每日数据」表: {e}")
        return None
    
    for supervisor in SUPERVISORS:
        try:
            ws = spreadsheet.worksheet(supervisor)
            rows = ws.get_all_values()
            
            # 跳过表头（第 1 行），从第 2 行开始
            for row_idx, row in enumerate(rows[1:], start=2):
                if len(row) < 5:
                    continue
                
                center = row[1].strip() if len(row) > 1 else ""   # 列 B
                company = row[2].strip() if len(row) > 2 else ""  # 列 C
                name = row[3].strip() if len(row) > 3 else ""     # 列 D (花名)
                peer = row[4].strip() if len(row) > 4 else ""     # 列 E (外事号)
                
                # 跳过空行和表尾合计行
                if not peer or not center:
                    continue
                if peer in ("合计", "总计", "Total"):
                    continue
                
                # 容错：商务公司 → 商务中心
                if center == "商务公司":
                    center = "商务中心"
                
                mapping[peer] = {
                    "中心": center,
                    "公司": company,
                    "花名": name,
                    "监察员": supervisor,
                    "Tab行号": row_idx,
                }
                stats[supervisor] += 1
                
                if center in centers:
                    centers[center] += 1
                else:
                    centers["其他"] += 1
                    
        except Exception as e:
            logger.error(f"读取 {supervisor} Tab 失败: {e}")
    
    # 保存到本地缓存
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    cache_data = {
        "mapping": mapping,
        "updated_at": datetime.now().isoformat(),
        "stats": stats,
        "centers": centers,
    }
    with open(CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump(cache_data, f, ensure_ascii=False, indent=2)
    
    logger.info(f"「每日数据」映射同步完成: 共 {len(mapping)} 个外事号")
    logger.info(f"  监察员分布: {stats}")
    logger.info(f"  中心分布: {centers}")
    
    return cache_data


def load_cache():
    """从本地 JSON 读映射表（运行时用，不访问 Google Sheet）"""
    if not CACHE_PATH.exists():
        return None
    try:
        with open(CACHE_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"读本地缓存失败: {e}")
        return None


def get_peer_info(peer_name):
    """
    查询某个外事号的归属信息
    
    参数:
        peer_name: 外事号昵称（如 "小叛逆"）
    
    返回:
        dict 或 None: {中心, 公司, 花名, 监察员, Tab行号}
    """
    cache = load_cache()
    if not cache:
        return None
    return cache.get("mapping", {}).get(peer_name)


if __name__ == "__main__":
    # 独立运行测试：python3 daily_sheet_sync.py
    import sys
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    
    # 用系统的 OAuth token
    try:
        import gspread
        from google.oauth2.credentials import Credentials
        
        TOKEN_PATH = BASE_DIR / "data" / "google_oauth_token.json"
        with open(TOKEN_PATH) as f:
            token = json.load(f)
        
        creds = Credentials(
            token=token.get("token") or token.get("access_token"),
            refresh_token=token.get("refresh_token"),
            client_id=token.get("client_id"),
            client_secret=token.get("client_secret"),
            token_uri="https://oauth2.googleapis.com/token",
            scopes=token.get("scopes"),
        )
        gc = gspread.authorize(creds)
        
        result = sync_from_sheet(gc)
        if result:
            print("\n=== 同步成功 ===")
            print(f"总外事号: {len(result['mapping'])}")
            print(f"更新时间: {result['updated_at']}")
            print(f"\n监察员分布:")
            for k, v in result['stats'].items():
                print(f"  {k}: {v} 个")
            print(f"\n中心分布:")
            for k, v in result['centers'].items():
                print(f"  {k}: {v} 个")
            
            # 测试查询
            print(f"\n=== 测试查询 ===")
            test_peer = "张心姿"
            info = get_peer_info(test_peer)
            if info:
                print(f"「{test_peer}」→ {info}")
            else:
                print(f"「{test_peer}」未找到")
        else:
            print("同步失败")
            sys.exit(1)
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
