# YYZL v4 升级 + 测试 Checklist

## 🎯 v4 改了什么

| 项 | v3 | v4 |
|---|---|---|
| 配色 | 米黄豆沙绿 | **深炭黑 (GitHub 风格)** |
| 群数量 | 2 个/中心 (怠工 + 风控) | **3 个/中心 (怠工 + 风控 + 档案)** |
| 风控群推什么 | 撤回/我方删/敏感词/图/语音/视频/文件/外链 | 撤回/我方删/敏感词 |
| 档案群推什么 | (无) | **图/语音/视频/文件/外链** |
| 预警里 @ 监察员 | ❌ 只有文字标签 | ✅ **@username + 文字** (推红点) |
| 设置页 01 部门 + 02 Bot | 显示 (但已不进 setup) | **整块砍掉** |
| 登 TG 号时填 | 中心/公司/归属人 + 2 群 ID | 中心/公司/归属人 + **3 群 ID** |
| 改归属人 | 删号重登 (打扰外事号) | ✅ **「编辑归属」按钮, 不重登** |

---

## 🚀 部署步骤

### 第 1 步:GitHub 替换 tar.gz

把 `yyzl-deploy-v4.tar.gz` 重命名为 `yyzl-deploy-v20260425_0603.tar.gz` (跟旧文件名一致), 上传到 GitHub 覆盖。

⚠️ install.sh 也要换 (本次有改) — 把 `install.sh` 也上传到 GitHub 替换。

### 第 2 步:测试 VPS 跑一键命令

```bash
cd /root
docker compose -f yyzl-deploy/docker-compose.yml down 2>/dev/null
mv yyzl-deploy yyzl-deploy-old-v3 2>/dev/null
# 跑你的一键命令
```

### 第 3 步:跟 4 问回答

跟之前一样:监察员/VPS号/Bot Token/Web 密码

### 第 4 步:登入 + 删旧 users.json

```bash
# 浏览器打不开请清旧 users.json (跟 v3 升级一样)
cd /root/yyzl-deploy
rm -f data/users.json
docker compose restart web
```

---

## ✅ 验证 Checklist

### Web 配色
- [ ] 全部改成深炭黑了 (GitHub 风格, #0D1117 背景)
- [ ] 不再是米黄豆沙绿

### 设置页
- [ ] 不再有「01 · 部门资讯」
- [ ] 不再有「02 · Telegram Bot」
- [ ] 只剩 03 + 04 + Sheet 同步等

### 中心管理页
- [ ] 每个中心显示 **3 个**群 ID 输入框 (怠工/风控/档案)
- [ ] 「新增中心」表单也是 3 个群

### 登 TG 号
- [ ] 登入成功后弹出 step-info 表单
- [ ] 表单有 3 个群 ID 输入 (怠工/风控/档案)

### 编辑归属 (新功能)
- [ ] 主页账号列表每行有「编辑归属」按钮
- [ ] 点击能填回原来归属信息
- [ ] 改完保存, 不重登 TG

### 预警内容
- [ ] 监察人员行: `@maixiaomai1110 (麦小麦1)`
- [ ] 监察员收到红点通知 (Telegram 桌面/手机弹窗)

### 路由
- [ ] 怠工 → 怠工群
- [ ] 撤回/敏感词 → 风控群
- [ ] 图/语音/视频/文件/外链 → **档案群**

---

## 🐛 常见问题

### 问题:登入页还是看到密码错
```bash
cd /root/yyzl-deploy
rm -f data/users.json
docker compose restart web
# 刷新浏览器, 用 admin + 安装时设的密码
```

### 问题:预警里没有 @
检查 .env:
```bash
grep TG_USERNAME /root/yyzl-deploy/.env
```
应该看到 `TG_USERNAME=maixiaomai1110` (麦小麦) 或对应 username。

如果是空的, 说明 install.sh 没读到共享配置. 修复:
```bash
echo "TG_USERNAME=maixiaomai1110" >> /root/yyzl-deploy/.env  # 改成你的 username
docker compose restart
```

### 问题:档案群没收到推送
检查 .env 里档案群 ID 是不是配了:
```bash
grep ALERT_ARCHIVE_GROUP /root/yyzl-deploy/.env
```
应该看到对应中心的群 ID. 没配就到 Web 后台「中心管理」配上.
