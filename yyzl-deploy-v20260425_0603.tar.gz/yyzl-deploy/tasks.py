"""定时任务 — 巡检、未回复检查、日报"""
import asyncio
import logging
from datetime import datetime, timedelta, timezone

import gspread

import config
import database as db
from sheets import _col_letter

logger = logging.getLogger(__name__)

TZ_BJ = timezone(timedelta(hours=8))


class TaskScheduler:
    def __init__(self, listener, sheets_writer, alert_bot, startup_time=None):
        self.listener = listener
        self.sheets = sheets_writer
        self.bot = alert_bot
        self.startup_time = startup_time  # 只对启动后的消息触发预警
        self._running = False

    async def start(self):
        self._running = True
        logger.info("定时任务启动")
        await asyncio.gather(
            self._sheets_flush_loop(),
            self._patrol_loop(),
            self._no_reply_loop(),
            # self._daily_report_loop(),  # v3: 日报已关闭
            self._peer_name_consistency_loop(),
            self._media_cleanup_loop(),
            self._update_check_loop(),
            self._session_health_loop(),   # v2.10.4: TG session 吊销检测
            self._daily_data_sync_loop(),  # v3: 每日数据写 Sheet
        )

    async def stop(self):
        self._running = False

    async def _sync_account_names(self):
        """检查 TG 账号昵称是否改变，同步更新 DB + Sheets 分页名 + 表头"""
        for phone, client in self.listener.clients.items():
            try:
                me = await client.get_me()
                new_name = ((me.first_name or "") + " " + (me.last_name or "")).strip()
                account = db.get_account_by_phone(phone)
                if not account or not new_name:
                    continue

                old_name = account["name"] or ""
                if new_name == old_name:
                    continue

                # 昵称变了
                logger.info("[%s] 昵称变更: %s → %s", phone, old_name, new_name)

                # 1. 更新 DB
                conn = db.get_conn()
                conn.execute("UPDATE accounts SET name=? WHERE id=?", (new_name, account["id"]))
                conn.commit()

                # 2. 同步 Sheets 分页名
                old_tab = account["sheet_tab"] or old_name
                try:
                    ws = self.sheets.spreadsheet.worksheet(old_tab)
                    self.sheets._rate_limit()
                    ws.update_title(new_name)
                    logger.info("分页名同步: %s → %s", old_tab, new_name)
                except Exception as e:
                    logger.warning("分页名同步失败: %s", e)

                # 3. 更新 DB 的 sheet_tab
                conn.execute("UPDATE accounts SET sheet_tab=? WHERE id=?", (new_name, account["id"]))
                conn.commit()

                # 4. 同步表头中的外事号名称（第5行）
                try:
                    ws = self.sheets.spreadsheet.worksheet(new_name)
                    self.sheets._rate_limit()
                    all_vals = ws.row_values(5)
                    for i, val in enumerate(all_vals):
                        if val == old_name:
                            col_letter = chr(65 + i) if i < 26 else chr(64 + i // 26) + chr(65 + i % 26)
                            self.sheets._rate_limit()
                            ws.update_acell(f"{col_letter}5", new_name)
                    logger.info("表头外事号名称已同步")
                except Exception as e:
                    logger.warning("表头同步失败: %s", e)

            except Exception as e:
                logger.warning("昵称同步失败 [%s]: %s", phone, e)

    async def _enforce_sheet_tab_consistency(self):
        """确保 Sheets 分页名 = account.name。用户手改分页名会被自动改回 TG 名字。"""
        for account in db.get_all_accounts():
            target = account["name"]
            if not target:
                continue
            # 已存在正确分页 → OK
            try:
                self.sheets._rate_limit()
                self.sheets.spreadsheet.worksheet(target)
                # 顺手把 sheet_tab 对齐
                if account["sheet_tab"] != target:
                    conn = db.get_conn()
                    conn.execute("UPDATE accounts SET sheet_tab=? WHERE id=?", (target, account["id"]))
                    conn.commit()
                continue
            except gspread.WorksheetNotFound:
                pass

            # 找旧 sheet_tab 对应的分页，改名回 target
            old = account["sheet_tab"]
            if not old or old == target:
                continue
            try:
                self.sheets._rate_limit()
                ws = self.sheets.spreadsheet.worksheet(old)
                self.sheets._rate_limit()
                ws.update_title(target)
                conn = db.get_conn()
                conn.execute("UPDATE accounts SET sheet_tab=? WHERE id=?", (target, account["id"]))
                conn.commit()
                logger.info("分页名自动修正: %s → %s", old, target)

                # 同步表头第 5 行
                try:
                    self.sheets._rate_limit()
                    row5 = ws.row_values(5)
                    for i, val in enumerate(row5):
                        if val == old:
                            col = chr(65 + i) if i < 26 else chr(64 + i // 26) + chr(65 + i % 26)
                            self.sheets._rate_limit()
                            ws.update_acell(f"{col}5", target)
                    logger.info("表头外事号名称已修正")
                except Exception as e:
                    logger.warning("表头修正失败: %s", e)
            except gspread.WorksheetNotFound:
                logger.warning("分页名修正：旧分页「%s」也不存在，跳过", old)
            except Exception as e:
                logger.warning("分页名修正失败 %s → %s: %s", old, target, e)

    async def _sheets_flush_loop(self):
        """每 N 秒批量写入 Sheets"""
        while self._running:
            try:
                count = self.sheets.flush_pending()
                if count:
                    logger.info("批量写入 %d 条消息到 Sheets", count)
            except Exception as e:
                logger.error("Sheets 写入失败: %s", e)
            await asyncio.sleep(config.SHEETS_FLUSH_INTERVAL)

    async def _patrol_loop(self):
        """每 60 秒巡检：补漏 + 删除检测 + 同步表头 + 昵称同步"""
        # 启动后等一会儿再开始巡检
        await asyncio.sleep(30)
        while self._running:
            try:
                # 从 Sheets 同步表头（商务人员、所属公司）
                self.sheets.sync_headers()

                # 检查账号昵称是否改变
                await self._sync_account_names()

                # 分页名一致性检查：手改的分页名会被自动改回 TG 名字
                await self._enforce_sheet_tab_consistency()

                # 预警分页名一致性:手改「信息删除预警YD」会被自动改回「信息删除预警{COMPANY_DISPLAY}」
                # 防止客户手贱改名后系统找不到分页 → 写入失败
                try:
                    self.sheets.ensure_alert_tabs()
                except Exception as e:
                    logger.warning("预警分页一致性巡检失败: %s", e)

                # v2.10.15: 账号分页自愈巡检 — 登录时 _create_sheet_tab 可能因为
                # Sheets API 429 / 瞬时网络 / OAuth token 过期而静默失败,
                # tg-monitor 启动 sweep 只跑一次。这里每轮巡检再扫一次,
                # 补建 DB 里有但 Sheet 里没有的账号分页(幂等)
                try:
                    self.sheets.ensure_account_tabs()
                except Exception as e:
                    logger.warning("账号分页自愈巡检失败: %s", e)

                for phone, client in self.listener.clients.items():
                    # 删除检测
                    deleted_msgs = await self.listener.check_deleted(phone, days=config.PATROL_DAYS)
                    for m in deleted_msgs:
                        peer = db.get_conn().execute(
                            "SELECT * FROM peers WHERE id=?", (m["peer_id"],)
                        ).fetchone()
                        if peer and self.bot:
                            # v3: sqlite3.Row 没有 .get(),用 try/except 安全取
                            try:
                                _direction = m["direction"]
                            except (KeyError, IndexError):
                                _direction = ""
                            await self.bot.send_delete_alert(
                                m["account_id"], peer, m["text"], m["msg_id"],
                                direction=_direction,
                            )
                            # 标记表格中的删除
                            account = db.get_conn().execute(
                                "SELECT * FROM accounts WHERE id=?", (m["account_id"],)
                            ).fetchone()
                            if account:
                                ws = self.sheets.get_or_create_sheet(account)
                                self.sheets.mark_deleted_in_sheet(ws, m)
            except Exception as e:
                logger.error("巡检失败: %s", e)
            await asyncio.sleep(config.PATROL_INTERVAL)

    async def _no_reply_loop(self):
        """每分钟检查未回复。按 WORK_SCHEDULE 精确判断工作时段：
        - 当前不在工作时段（午休 13-15 / 晚休 19-20 / 周日等）→ 跳过
        - 累计未回复分钟按工作时段算（非工作时段不累计）"""
        await asyncio.sleep(15)
        while self._running:
            try:
                now = datetime.now(TZ_BJ)

                # 当前不在工作时段 → 这一轮不发任何预警
                if not config.is_work_time(now):
                    await asyncio.sleep(60)
                    continue

                accounts = db.get_all_accounts()
                for account in accounts:
                    candidates = db.get_unanswered_candidates(account["id"])
                    for row in candidates:
                        try:
                            last_dt = datetime.strptime(row["last_time"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=TZ_BJ)
                        except Exception:
                            continue

                        # 按工作时段累计分钟（午休/晚休/周日不算）
                        elapsed = config.work_elapsed_minutes(last_dt, now)
                        if elapsed < config.NO_REPLY_MINUTES:
                            continue

                        # 启动前已远超阈值的远古消息不补推
                        if self.startup_time:
                            try:
                                startup_dt = datetime.strptime(self.startup_time, "%Y-%m-%d %H:%M:%S").replace(tzinfo=TZ_BJ)
                                if config.work_elapsed_minutes(last_dt, startup_dt) > config.NO_REPLY_MINUTES:
                                    continue
                            except Exception:
                                pass

                        peer = db.get_peer(row["tg_id"], account["id"])
                        if peer and yyzl_filter.should_skip_no_reply_alert(db, peer["id"], account["id"]):
                            continue
                        if peer and self.bot:
                            await self.bot.send_no_reply_alert(
                                account["id"], peer,
                                row["last_text"], row["last_msg_id"]
                            )
                            logger.info("未回复预警: %s <- %s (累计 %.1f 工作分钟)",
                                        account['name'], peer['name'], elapsed)
            except Exception as e:
                logger.error("未回复检查失败: %s", e)
            await asyncio.sleep(60)

    async def _peer_name_consistency_loop(self):
        """每 10 分钟巡检广告主名是否跟 DB 一致，对方在 TG 改名会通过新消息更新到 DB，
        这个 loop 把 DB 的最新名字同步回 Sheets 表头的第 6 行 C 列（或 F6, I6, L6...）"""
        # 启动后等一会儿
        await asyncio.sleep(120)
        while self._running:
            try:
                for account in db.get_all_accounts():
                    ws = self.sheets.get_or_create_sheet(account)
                    if not ws:
                        continue
                    peers = db.get_peers_by_account(account["id"])
                    peers = [p for p in peers if p["col_group"] >= 0]
                    if not peers:
                        continue

                    # 一次读取第 6 行
                    try:
                        self.sheets._rate_limit()
                        row6 = ws.row_values(6)
                    except Exception as e:
                        logger.warning("读 row 6 失败 [%s]: %s", account["name"], e)
                        continue

                    role_label = config.PEER_ROLE_LABEL
                    updates = []  # [(range, value)]
                    for peer in peers:
                        col_group_b = peer["col_group"] * 3 + 1  # B 列索引（role 标签）
                        col_group_c = peer["col_group"] * 3 + 2  # C 列索引（peer name）
                        # 同步 peer 名
                        current_name = row6[col_group_c] if col_group_c < len(row6) else ""
                        target_name = peer["name"] or f"用户{peer['tg_id']}"
                        if current_name and current_name != target_name:
                            updates.append((f"{_col_letter(col_group_c)}6", target_name))
                        # 同步 role 标签（广告主 → 客户/合作方等）
                        current_label = row6[col_group_b] if col_group_b < len(row6) else ""
                        if current_label and current_label != role_label:
                            updates.append((f"{_col_letter(col_group_b)}6", role_label))

                    if updates:
                        try:
                            self.sheets._rate_limit()
                            ws.batch_update([
                                {"range": cell, "values": [[val]]}
                                for cell, val in updates
                            ])
                            for cell, val in updates:
                                logger.info("广告主名同步 [%s] %s → %s", account["name"], cell, val)
                        except Exception as e:
                            logger.warning("广告主名批量更新失败 [%s]: %s", account["name"], e)
            except Exception as e:
                logger.error("广告主名一致性巡检失败: %s", e)
            await asyncio.sleep(config.PATROL_INTERVAL)  # 预设 60 秒

    async def _media_cleanup_loop(self):
        """每天北京时间 03:00 清理 Drive 里超过 MEDIA_RETENTION_DAYS 天的旧媒体。
        MEDIA_RETENTION_DAYS=0 时 loop 还是照跑(睡到点再 check),客户改设置后下一轮立刻生效。"""
        while self._running:
            now = datetime.now(TZ_BJ)
            target = now.replace(hour=3, minute=0, second=0, microsecond=0)
            if target <= now:
                target = target + timedelta(days=1)
            wait_s = (target - now).total_seconds()
            logger.info("下次媒体清理在 %s (北京时间)", target.strftime('%Y-%m-%d %H:%M:%S'))
            await asyncio.sleep(wait_s)

            try:
                # 动态读(客户可能在 web 后台改了 MEDIA_RETENTION_DAYS,但 config 没 reload)
                # → 每次跑都从 .env 重新读一次
                import importlib
                importlib.reload(config)
                days = int(getattr(config, "MEDIA_RETENTION_DAYS", 0) or 0)
                if days <= 0:
                    logger.info("MEDIA_RETENTION_DAYS=0, 跳过自动清理")
                    continue
                import media_uploader
                deleted, failed = media_uploader.cleanup_old_media(days)
                logger.info("每日媒体清理完成: 删 %d 失败 %d", deleted, failed)
            except Exception as e:
                logger.error("每日媒体清理失败: %s", e)

    async def _update_check_loop(self):
        """v2.9.0: 每 6 小时查一次 GitHub 有没有新版,有就推 TG 通知(同版本只推一次)。
        启动 60 秒后第一次 check,之后每 6 小时一次(一天 4 次;急用户 Dashboard 有手动刷新按钮)。"""
        import update_checker
        await asyncio.sleep(60)  # 启动后稍等一下,让 listener/bot 都就位
        while self._running:
            try:
                await update_checker.check_and_notify(self.bot)
            except Exception as e:
                logger.warning(f"update check loop error: {e}")
            await asyncio.sleep(6 * 3600)  # 6 小时

    # v2.10.4: session 吊销检测 ----------------------------------------
    SESSION_STATE_FILE = "/app/data/.session_states.json"
    SESSION_CHECK_INTERVAL = 300   # 5 分钟一次
    SESSION_FIRST_DELAY = 90       # 启动后等 90s 再开始(避开启动期的 flaky)

    def _load_session_states(self):
        import json, os
        try:
            if os.path.exists(self.SESSION_STATE_FILE):
                with open(self.SESSION_STATE_FILE, "r") as f:
                    return json.load(f)
        except Exception as e:
            logger.warning("载入 session_states 失败: %s", e)
        return {}

    def _save_session_states(self, states):
        import json, os
        try:
            os.makedirs(os.path.dirname(self.SESSION_STATE_FILE), exist_ok=True)
            tmp = self.SESSION_STATE_FILE + ".tmp"
            with open(tmp, "w") as f:
                json.dump(states, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.SESSION_STATE_FILE)
        except Exception as e:
            logger.warning("保存 session_states 失败: %s", e)

    async def _check_single_session(self, phone, client):
        """返回 'healthy' | 'revoked' | 'error'"""
        try:
            if not client.is_connected():
                try:
                    await asyncio.wait_for(client.connect(), timeout=15)
                except Exception as e:
                    logger.warning("[session_check] %s connect 失败: %s", phone, e)
                    return "error"
            authorized = await asyncio.wait_for(client.is_user_authorized(), timeout=10)
            return "healthy" if authorized else "revoked"
        except Exception as e:
            msg = str(e)
            if any(k in msg for k in ("AuthKey", "Unauthorized", "Deactivated", "Revoked")):
                return "revoked"
            logger.warning("[session_check] %s 检查异常: %s", phone, e)
            return "error"

    async def _session_health_loop(self):
        """每 5 分钟检查每个 client 的 is_user_authorized()。
        healthy→revoked 推吊销预警;revoked→healthy 推恢复通知。
        首次启动用现状作基线,不报警,避免启动期炸群。
        'error' 状态不触发转场(可能是临时网络问题)。"""
        await asyncio.sleep(self.SESSION_FIRST_DELAY)
        prev = self._load_session_states()
        first_round = not prev   # 没状态文件 = 第一次跑
        while self._running:
            try:
                current = {}
                for phone, client in list(self.listener.clients.items()):
                    status = await self._check_single_session(phone, client)
                    current[phone] = {
                        "status": status,
                        "last_check": db.now_bj(),
                    }
                    prev_status = (prev.get(phone) or {}).get("status")
                    if first_round:
                        continue
                    if status == "revoked" and prev_status != "revoked":
                        logger.warning("[session] %s 吊销 (prev=%s)", phone, prev_status)
                        await self._emit_session_alert("revoked", phone)
                    elif status == "healthy" and prev_status == "revoked":
                        logger.info("[session] %s 已恢复", phone)
                        await self._emit_session_alert("restored", phone)
                for phone, st in prev.items():
                    if phone not in current:
                        current[phone] = st
                self._save_session_states(current)
                prev = current
                first_round = False
            except Exception as e:
                logger.error("session_health_loop 异常: %s", e)
            await asyncio.sleep(self.SESSION_CHECK_INTERVAL)

    async def _emit_session_alert(self, kind, phone):
        """找到 account_id + name 再丢给 bot.send_session_alert"""
        try:
            row = db.get_conn().execute(
                "SELECT id, name FROM accounts WHERE phone=?", (phone,)
            ).fetchone()
            aid = row["id"] if row else 0
            name = row["name"] if row else ""
            if self.bot:
                await self.bot.send_session_alert(kind, phone, account_id=aid, account_name=name)
        except Exception as e:
            logger.warning("_emit_session_alert 失败 phone=%s kind=%s: %s", phone, kind, e)
    # -----------------------------------------------------------------

    def _next_daily_report_time(self, now):
        """下一个日报发送时间 (北京时间):
        周一~五 21:30 (柬埔寨 20:30), 周六 18:30 (柬埔寨 17:30), 周日跳过
        """
        for delta in range(8):
            cand = now + timedelta(days=delta)
            wd = cand.weekday()
            if wd <= 4:
                target = cand.replace(hour=21, minute=30, second=0, microsecond=0)
            elif wd == 5:
                target = cand.replace(hour=18, minute=30, second=0, microsecond=0)
            else:
                continue
            if target > now:
                return target
        return now + timedelta(days=1)

    async def _daily_report_loop(self):
        """日报: 周一~五 北京21:30(柬20:30), 周六 北京18:30(柬17:30), 周日不发"""
        while self._running:
            now = datetime.now(TZ_BJ)
            next_dt = self._next_daily_report_time(now)
            wait_seconds = (next_dt - now).total_seconds()
            logger.info("下次日报在 %s (北京时间)，等待 %d秒", next_dt.strftime('%Y-%m-%d %H:%M:%S'), int(wait_seconds))
            await asyncio.sleep(wait_seconds)

            try:
                if self.bot:
                    await self.bot.send_daily_report()
            except Exception as e:
                logger.error("日报发送失败: %s", e)


    async def _daily_data_sync_loop(self):
        """每日数据写入 Sheet 的循环 - v3
        触发: 柬周一至五 20:30 / 周六 17:30 / 周日跳过
        """
        import os
        from datetime import datetime, timedelta, timezone
        TZ_KH = timezone(timedelta(hours=7))

        sheet_id = os.environ.get("DAILY_SHEET_ID", "").strip()
        sheet_gid = os.environ.get("DAILY_SHEET_GID", "").strip()
        if not sheet_id or not sheet_gid:
            logger.warning("[daily_sync_loop] DAILY_SHEET_ID/GID 未配置, 不启动")
            return

        logger.info(f"[daily_sync_loop] 启动, gid={sheet_gid}")
        last_synced_date = None

        while True:
            try:
                now_kh = datetime.now(TZ_KH)
                wd = now_kh.weekday()
                today_kh = now_kh.date()

                if wd == 6:
                    await asyncio.sleep(60)
                    continue

                target_h, target_m = (17, 30) if wd == 5 else (20, 30)
                hit = (now_kh.hour == target_h and now_kh.minute == target_m)

                if hit and last_synced_date != today_kh:
                    logger.info(f"[daily_sync_loop] 触发: {now_kh.strftime('%Y-%m-%d %H:%M')} (柬)")
                    try:
                        from daily_data_writer import run_daily_sync
                        success, msg = run_daily_sync(sheet_id, sheet_gid)
                        logger.info(f"[daily_sync_loop] 结果: success={success} msg={msg}")
                        last_synced_date = today_kh
                    except Exception as e:
                        logger.error(f"[daily_sync_loop] 异常: {e}", exc_info=True)
                        last_synced_date = today_kh

            except Exception as e:
                logger.error(f"[daily_sync_loop] 外层异常: {e}", exc_info=True)

            await asyncio.sleep(60)
