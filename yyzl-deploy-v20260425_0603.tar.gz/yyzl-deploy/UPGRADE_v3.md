# YYZL v3 升级 + 测试 Checklist

## 🎯 第一次跑(在你的测试 VPS 上)

### 步骤 1:把新 tar.gz 上传到测试 VPS

我会打包成 `yyzl-deploy-v3.tar.gz` 给你下载。

你可以选两种方式:

**方式 A:直接替换 GitHub 上的 tar.gz**
1. 把 `yyzl-deploy-v3.tar.gz` 重命名为 `yyzl-deploy-v20260425_0603.tar.gz`(保持文件名)
2. 上传到 GitHub Private Repo 覆盖
3. 跑一键命令(install.sh 不变)

**方式 B:测试机上直接传新包(更快)**
1. 把 `yyzl-deploy-v3.tar.gz` 上传到桌面
2. 用 `python3 -m http.server 9999` 在你电脑起服务
3. 测试 VPS 跑 `wget http://你电脑IP:9999/yyzl-deploy-v3.tar.gz`
4. 在 VPS 上 `tar xzf` + `bash 安装.sh`

---

### 步骤 2:在测试 VPS 上跑

```bash
# 先停旧的
cd /root/yyzl-deploy
docker compose down

# 备份旧 sessions 和 data(可选,旧 sessions 复用就不用重登 TG)
cd /root
mv yyzl-deploy yyzl-deploy-old-v2

# 解压新版
tar xzf yyzl-deploy-v3.tar.gz
cd yyzl-deploy

# 复用旧 session 不用重登 TG(可选)
cp -r /root/yyzl-deploy-old-v2/sessions ./
cp -r /root/yyzl-deploy-old-v2/data ./

# 跑安装
bash 安装.sh
```

---

## ✅ 测试 Checklist

### ① 安装脚本(终端)
- [ ] 监察员选择(1-4)出现且能选
- [ ] VPS 编号能输 1-9
- [ ] Bot Token 输入隐藏
- [ ] Web 密码输入隐藏 + 二次确认
- [ ] 容器启动成功
- [ ] 最后输出的 IP 是 IPv4(不是 IPv6)
- [ ] 显示「监察员:麦小麦」「VPS 编号:1 号机」「预警显示:麦小麦1」

### ② 浏览器打开 http://IP:8000
- [ ] **不再**出现「首次部署向导」黑色页面 ⚠️
- [ ] 出现的是登入页(白米色背景)
- [ ] 用 admin + 你设的密码能登入

### ③ 主页(/)
- [ ] 主色是米黄豆沙绿(不是绿松石蓝)
- [ ] 顶部菜单能看到「驾驶舱 / 账号管理 / 中心管理 / 敏感词 / 设置」
- [ ] 点「中心管理」能进入

### ④ 中心管理页(/centers)
- [ ] 列出 4 个默认中心(商务/渠道/运营/恒丰)
- [ ] 每个中心有「怠工群 ID」「风控群 ID」两个输入框
- [ ] 怠工群 ID 已经填好(从共享配置.env 来)
- [ ] 风控群 ID 是空的
- [ ] 填一个测试的群 ID,点「保存」,显示成功
- [ ] 试新增一个中心(例如 测试中心 / TEST),能加成功
- [ ] 删除测试中心成功
- [ ] 默认 4 个中心**不能**删

### ⑤ 敏感词管理页(/sensitive_words)
- [ ] 列出默认 5 个敏感词(地址/到期/续费/催款/结算)
- [ ] 输入新词点「添加」能加
- [ ] 点 ✕ 能删
- [ ] 点「保存所有改动」成功

### ⑥ 登 Telegram 号(在主页)
- [ ] 输入手机号 + 发送验证码
- [ ] 输入验证码后,**不再**直接结束,而是出现 step-info 表单
- [ ] step-info 有:中心下拉 / 公司输入 / 归属人输入
- [ ] 中心下拉里能看到 4 个中心 + 状态标记(✅/⚠)
- [ ] 选了一个**没配风控群**的中心 → 出现群 ID 输入框
- [ ] 填中心 + 公司 + 归属人 + 群 ID,点「保存归属信息」成功
- [ ] 已登录账号列表显示正确

### ⑦ Google Sheet 自动创建
- [ ] 进设置页 → OAuth 授权流程
- [ ] 点「自动建表格」
- [ ] **新建的 Sheet 文件名是「麦小麦1」**(不是 TG监控-yyzl)

### ⑧ 实际触发预警(关键!)

需要先在「每日数据 Sheet」的麦小麦分页(GID 897421260)填几行数据:

| A 日期 | B 中心 | C 公司 | D 花名 | E 外事号 | F G H I |
|---|---|---|---|---|---|
| 2026-04-28 | 商务中心 | 领航公司 | 陈新吉 | 悦悦-【官方收量】 | (空) |

然后等容器读这个数据(每分钟读一次)。

**触发各类预警**:
- [ ] 用一个外事号 30 分钟不回复对方消息 → **怠工预警**到商务**怠工**群
- [ ] 用外事号发一张图片 → **风控预警 - 商务** + 图片 到商务**风控**群
- [ ] 用外事号发一段语音 → 风控预警(发送语音)
- [ ] 用外事号发一个文件 → 风控预警(发送文件)
- [ ] 用外事号发一条带链接的消息 → 风控预警(发送外链)
- [ ] 对方发「催款」 → 风控预警(出现敏感词「催款」)
- [ ] 外事号删除一条自己发的消息 → 风控预警(我方删除对话)
- [ ] 对方撤回一条消息 → 风控预警(对方撤回消息)

**所有预警里**:
- [ ] 标题里中心名对(商务/渠道/运营/恒丰)
- [ ] 中心/公司 行对
- [ ] 人员/外事号昵称 行对
- [ ] 监察人员: **麦小麦1** (不是「麦小麦 / VPS: 麦小麦-1号机」)

---

## 🐛 如果遇到问题

### 问题 1:打开 http://IP:8000 还是看到首次部署向导

```bash
# 检查 .env 里 SETUP_COMPLETE 是不是 true
cat /root/yyzl-deploy/.env | grep SETUP_COMPLETE
# 应该输出: SETUP_COMPLETE=true

# 如果没有,手动加上
echo "SETUP_COMPLETE=true" >> /root/yyzl-deploy/.env
docker compose restart web
```

### 问题 2:登入页提示用户名/密码错

```bash
# 用户名固定是 admin,密码是你 install.sh 输入的
# 如果忘了,改 .env 然后重启
sed -i 's/^WEB_PASSWORD=.*/WEB_PASSWORD=新密码/' /root/yyzl-deploy/.env
# 删除老的 users.json 让它重建
rm -f /root/yyzl-deploy/data/users.json
docker compose restart web
```

### 问题 3:预警没收到

```bash
# 看监听器日志
docker logs tg-monitor-yyzl --tail 100

# 查看路由有没有匹配
docker exec tg-monitor-yyzl python3 center_router.py
```

### 问题 4:预警里显示「未知中心 / 未指定」

意思是这个外事号没在「每日数据 Sheet」里登记。
解决:在 Sheet 里加一行,然后等 5-30 分钟(daily_sheet_sync 缓存刷新)。

或手动重启容器立刻刷新:
```bash
docker compose restart tg-monitor
```

---

## 🚨 还原到老版

如果跑不通,回到旧版:

```bash
cd /root
docker compose -f /root/yyzl-deploy/docker-compose.yml down
mv yyzl-deploy yyzl-deploy-v3-failed
mv yyzl-deploy-old-v2 yyzl-deploy
cd yyzl-deploy
docker compose up -d
```
