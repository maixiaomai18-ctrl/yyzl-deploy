"""推送消息模板 — YYZL 中心分发版 v2"""
import config
from datetime import datetime
try:
    import pytz
    BJ_TZ = pytz.timezone('Asia/Shanghai')
    KH_TZ = pytz.timezone('Asia/Phnom_Penh')
except ImportError:
    BJ_TZ = None
    KH_TZ = None


# ============================================================
# 工具函数
# ============================================================
def _format_peer_info(peer_name, peer_username):
    """
    广告主信息格式化
    优先级：username → (未设置ID)
    返回：'别抖掉梦 / @FgJGHFgJGBuN' 或 '别抖掉梦 / (未设置ID)'
    """
    name = peer_name if peer_name else "(未知)"
    if peer_username:
        # 清理 username（去掉可能的 @ 前缀）
        uname = peer_username.lstrip('@').strip()
        if uname:
            return f"{name} / @{uname}"
    return f"{name} / (未设置ID)"


def _get_center_company(company):
    """
    把 company 字段拆成「中心/公司」两段
    输入可能是：'商务中心 / 鼎丰公司' 或 '商务中心' 或 ''
    输出：始终返回 '中心 / 公司' 格式
    """
    if not company:
        return "(未归属) / (未归属)"
    if " / " in company:
        return company  # 已经是正确格式
    if "/" in company:
        parts = [p.strip() for p in company.split("/", 1)]
        return " / ".join(parts)
    # 只有中心没有公司
    return f"{company} / (未归属)"


def _now_kh():
    """柬埔寨当前时间"""
    if KH_TZ:
        return datetime.now(KH_TZ).strftime("%Y-%m-%d %H:%M")
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def _get_vps_code():
    """从环境变量拿 VPS 编号"""
    import os
    return os.getenv("VPS_CODE", "未知")


def _get_operator_name():
    """从环境变量拿监察员名字（当前 VPS 所属）"""
    import os
    return os.getenv("OPERATOR_NAME", "未知")


# ============================================================
# 1. 未回复预警
# ============================================================
def no_reply_alert(company, operator, account_name, peer_name, message_text,
                   peer_username="", reply_type="已读", overtime_minutes=10,
                   count=1):
    """
    未回复预警（新格式）
    
    参数:
        company:         中心/公司（来自 accounts.company）
        operator:        业务员花名（来自 accounts.operator，即 Sheet D 列「花名」）
        account_name:    外事号昵称（来自 accounts.name，即 TG 账号显示名）
        peer_name:       广告主 TG 显示名
        peer_username:   广告主 @username（可选）
        message_text:    客户消息内容
        reply_type:      '已读' 或 '未读'
        overtime_minutes: 超时分钟数
        count:           未回复条数
    """
    center_company = _get_center_company(company)
    peer_info = _format_peer_info(peer_name, peer_username)
    
    # 问题事项（只保留"长时间未查看消息"）
    issue_text = f"长时间未查看消息 {count} 例"
    
    # 日期（柬埔寨时间 M/D）
    if KH_TZ:
        date_str = datetime.now(KH_TZ).strftime("%-m/%-d")
    else:
        date_str = datetime.now().strftime("%-m/%-d")
    
    return (
        f"⚠️ 未查看消息预警\n"
        f"━━━━━━━━━━━━━━━\n"
        f"日期: {date_str}\n"
        f"中心/公司: {center_company}\n"
        f"人员/外事号昵称: {operator} / {account_name}\n"
        f"广告主: {peer_info}\n"
        f"问题事项: {issue_text}\n"
        f"━━━━━━━━━━━━━━━\n"
        f"⏰ 触发时间: {_now_kh()} (柬)\n"
        f"🔍 监察员: {_get_operator_name()} / VPS: {_get_vps_code()}"
    )


# ============================================================
# 2. 消息删除预警
# ============================================================
def delete_alert(company, operator, account_name, peer_name, message_text="",
                 peer_username="", delete_time=""):
    """
    消息删除预警（新格式）
    
    参数:
        company:         中心/公司
        operator:        业务员花名
        account_name:    外事号昵称
        peer_name:       广告主 TG 显示名
        peer_username:   广告主 @username（可选）
        message_text:    被删除的消息内容
        delete_time:     删除时间（可选）
    """
    center_company = _get_center_company(company)
    peer_info = _format_peer_info(peer_name, peer_username)
    
    msg_preview = message_text if message_text else "(消息内容未记录)"
    if len(msg_preview) > 200:
        msg_preview = msg_preview[:200] + "..."
    
    text = (
        f"🗑 消息删除预警\n"
        f"━━━━━━━━━━━━━━━\n"
        f"中心/公司: {center_company}\n"
        f"人员/外事号昵称: {operator} / {account_name}\n"
        f"广告主: {peer_info}\n"
        f"问题事项: 检测到消息被删除\n"
        f"━━━━━━━━━━━━━━\n"
        f"💬 原消息: \"{msg_preview}\"\n"
    )
    if delete_time:
        text += f"⏰ 删除时间: {delete_time}\n"
    text += (
        f"⏰ 触发时间: {_now_kh()} (柬)\n"
        f"🔍 监察员: {_get_operator_name()} / VPS: {_get_vps_code()}"
    )
    return text


# ============================================================
# 3. 关键词预警
# ============================================================
def keyword_alert(company, operator, account_name, peer_name, keyword, message_text,
                  peer_username=""):
    """
    关键词预警（新格式）
    
    参数:
        company:         中心/公司
        operator:        业务员花名
        account_name:    外事号昵称
        peer_name:       广告主 TG 显示名
        peer_username:   广告主 @username（可选）
        keyword:         触发的关键词
        message_text:    原消息内容
    """
    center_company = _get_center_company(company)
    peer_info = _format_peer_info(peer_name, peer_username)
    
    msg_preview = message_text if message_text else "(空消息)"
    if len(msg_preview) > 200:
        msg_preview = msg_preview[:200] + "..."
    
    return (
        f"🚨 关键词预警\n"
        f"━━━━━━━━━━━━━━━\n"
        f"中心/公司: {center_company}\n"
        f"人员/外事号昵称: {operator} / {account_name}\n"
        f"广告主: {peer_info}\n"
        f"问题事项: 触发关键词「{keyword}」\n"
        f"━━━━━━━━━━━━━━━\n"
        f"💬 原消息: \"{msg_preview}\"\n"
        f"⏰ 触发时间: {_now_kh()} (柬)\n"
        f"🔍 监察员: {_get_operator_name()} / VPS: {_get_vps_code()}"
    )


# ============================================================
# 4. 日报（保持原格式不变，因为日报群推送会被关掉）
# ============================================================
def daily_report(report_date, record_time, chat_count,
                 no_reply_count, delete_count, keyword_count,
                 no_reply_detail=None, delete_detail=None):
    """
    no_reply_detail / delete_detail: 可选 dict {"approved": n, "pending": n, "rejected": n}
    有值时日报会附上审批分桶 (已通过 / 待审 / 已拒)
    """
    def _fmt(total, detail):
        if not detail:
            return f"{total}"
        return f"{total}  (已通过 {detail.get('approved', 0)} / 待审 {detail.get('pending', 0)} / 已拒 {detail.get('rejected', 0)})"
    
    return (
        f"【外事号监控总结】\n\n"
        f"统计日期: {report_date}\n"
        f"记录时间: {record_time}\n"
        f"监控聊天总数: {chat_count}\n"
        f"未回复数量: {_fmt(no_reply_count, no_reply_detail)}\n"
        f"信息删除数量: {_fmt(delete_count, delete_detail)}\n"
        f"关键词监听数量: {keyword_count}"
    )


# ============================================================
# 5. 会话被吊销/恢复（保持原样）
# ============================================================
def session_revoked_alert(phone, account_name):
    """v2.10.4: TG 会话被吊销(用户在 TG 官方 App 点「终止其他会话」会触发)"""
    return (
        f"⚠️ 【TG 会话被吊销】\n\n"
        f"外事号: {account_name}\n"
        f"手机: {phone}\n\n"
        f"该账号已被终止会话，需要重新登录。\n"
        f"请到 Web 后台重新扫码登录。"
    )


def session_restored_alert(phone, account_name):
    """会话恢复"""
    return (
        f"✅ 【TG 会话已恢复】\n\n"
        f"外事号: {account_name}\n"
        f"手机: {phone}\n\n"
        f"账号已重新登录成功，监控继续运行。"
    )
