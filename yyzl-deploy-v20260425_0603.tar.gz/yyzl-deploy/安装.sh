#!/bin/bash
# YYZL TG 监控系统 - 一键安装脚本
# 监察员只需在解压后的 yyzl-deploy 目录里跑: bash 安装.sh

set -e

echo ""
echo "============================================"
echo "  YYZL TG 监控系统 - 一键安装"
echo "============================================"
echo ""

# 检查是否在正确目录
if [ ! -f "共享配置.env" ] || [ ! -f "Dockerfile" ]; then
    echo "X 错误: 请在解压后的 yyzl-deploy 目录里跑此脚本"
    echo "   正确做法:"
    echo "   cd /root && tar -xzf yyzl-deploy-vXXXX.tar.gz && cd yyzl-deploy && bash 安装.sh"
    exit 1
fi

echo "[1/7] 检查 Docker..."
if ! command -v docker &> /dev/null; then
    echo "  Docker 未安装,正在自动安装(约 2 分钟)..."
    curl -fsSL https://get.docker.com | sh > /dev/null 2>&1
    if ! command -v docker &> /dev/null; then
        echo "  X Docker 安装失败,请手动安装后重试"
        exit 1
    fi
fi
echo "  OK Docker 已就绪 ($(docker --version | cut -d, -f1))"

echo ""
echo "[2/7] 选择监察员身份..."
echo "  请告诉我你是哪一位监察员?"
echo ""
echo "  1) 麦小麦"
echo "  2) 季霖"
echo "  3) 吴苍河"
echo "  4) 陈家碧"
echo ""
while true; do
    read -p "  输入数字 [1-4]: " choice
    case "$choice" in
        1) OPERATOR_NAME="麦小麦"; SHEET_GID="897421260"; break;;
        2) OPERATOR_NAME="季霖"; SHEET_GID="1607202551"; break;;
        3) OPERATOR_NAME="吴苍河"; SHEET_GID="1109052736"; break;;
        4) OPERATOR_NAME="陈家碧"; SHEET_GID="1232047050"; break;;
        *) echo "  请输入 1/2/3/4";;
    esac
done
echo "  OK 你是: $OPERATOR_NAME"

echo ""
echo "[3/7] 这是你的第几台 VPS?"
echo "  (如果你只有 1 台,输 1; 第二台输 2,以此类推)"
echo "  这个数字会用作 VPS 编号,显示在预警通知里"
echo ""
read -p "  输入 VPS 编号 [1-9]: " VPS_NUM
if ! [[ "$VPS_NUM" =~ ^[1-9]$ ]]; then
    VPS_NUM=1
fi
VPS_CODE="${OPERATOR_NAME}-${VPS_NUM}号机"
echo "  OK VPS 编号: $VPS_CODE"

echo ""
echo "[4/7] 输入你的 Bot Token..."
echo "  Bot Token 由 @BotFather 提供, 长这样: 8139923255:AAH..."
echo "  (粘贴时屏幕不会显示, 这是正常的, 粘贴完直接按 Enter)"
echo ""
while true; do
    read -s -p "  Bot Token: " BOT_TOKEN
    echo ""
    if [[ "$BOT_TOKEN" =~ ^[0-9]+:.+ ]]; then
        echo "  OK Bot Token 格式正确 (隐藏)"
        break
    else
        echo "  X 格式错误,应该是 数字:字母数字 的格式,请重新粘贴"
    fi
done

echo ""
echo "[5/7] 设置 Web 后台密码..."
echo "  这个密码用来登入 Web 后台 (用来登 Telegram 号、看监控)"
echo "  建议至少 8 位"
echo ""
while true; do
    read -s -p "  设置 Web 密码: " WEB_PASSWORD
    echo ""
    if [ ${#WEB_PASSWORD} -lt 6 ]; then
        echo "  X 密码至少 6 位"
        continue
    fi
    read -s -p "  再输一次确认: " WEB_PASSWORD2
    echo ""
    if [ "$WEB_PASSWORD" != "$WEB_PASSWORD2" ]; then
        echo "  X 两次不一致,请重新输入"
        continue
    fi
    echo "  OK 密码已设置"
    break
done
METRICS_TOKEN=$(head /dev/urandom | tr -dc A-Za-z0-9 | head -c 32)

echo ""
echo "[6/7] 生成 .env 配置文件..."
{
    cat 共享配置.env
    echo ""
    echo "# === 监察员独有配置 (本机) ==="
    echo "OPERATOR_NAME=${OPERATOR_NAME}"
    echo "VPS_CODE=${VPS_CODE}"
    echo "BOT_TOKEN=${BOT_TOKEN}"
    echo "DAILY_SHEET_GID=${SHEET_GID}"
    echo "WEB_PASSWORD=${WEB_PASSWORD}"
    echo "METRICS_TOKEN=${METRICS_TOKEN}"
    echo "INSTALL_DIR=$(pwd)"
} > .env
chmod 600 .env
echo "  OK .env 已生成 (权限 600,只有你能读)"

echo ""
echo "[7/7] 启动 Docker 容器..."
echo "  这一步约需 2-3 分钟 (拉镜像 + 装依赖 + 启动)"
echo ""
docker compose up -d --build 2>&1 | tail -10
echo ""

echo "  等待 15 秒让容器完全启动..."
sleep 15

if docker ps | grep -q "tg-monitor"; then
    echo "  OK 容器启动成功!"
else
    echo "  X 容器启动失败,请联系麦小麦协助"
    docker compose logs --tail 20
    exit 1
fi

VPS_IP=$(curl -s -m 5 ifconfig.me 2>/dev/null || echo "你的VPS外网IP")

echo ""
echo "============================================"
echo "  OK 安装全部完成!"
echo "============================================"
echo ""
echo "  监察员: $OPERATOR_NAME"
echo "  VPS:    $VPS_CODE"
echo "  IP:     $VPS_IP"
echo ""
echo "  下一步: 用浏览器登入 Web 后台"
echo ""
echo "  ===== 重要: 浏览器打开下面这个链接 ====="
echo ""
echo "    http://${VPS_IP}:8000"
echo ""
echo "  ===================================="
echo ""
echo "  登入步骤:"
echo "    1. 用刚才设的 Web 密码登入"
echo "    2. 进入'账号管理',添加你的 Telegram 号"
echo "    3. 输入手机号,接收 Telegram 验证码"
echo "    4. 完成! 系统会自动开始监听"
echo ""
echo "  常用命令:"
echo "    看运行状态:  docker ps"
echo "    看日志:      docker logs tg-monitor-yyzl --tail 50"
echo "    重启:        cd $(pwd) && docker compose restart"
echo ""
echo "  如有问题,在 Telegram 找麦小麦"
echo ""
