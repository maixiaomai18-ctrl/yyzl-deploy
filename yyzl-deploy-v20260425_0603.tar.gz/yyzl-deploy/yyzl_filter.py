"""YYZL v3 - 寒暄/表情过滤"""

_GREETING_WORDS = {
    "在吗", "在不在", "在么", "你好", "您好", "hi", "hello", "嗨",
    "?", "？", "??", "？？", "哈喽", "哈罗", "早", "早安", "晚安",
    "早上好", "晚上好", "您在吗", "在？", "在?",
}


def _is_greeting_or_emoji(text_str):
    """判断一条消息文本是不是寒暄/单表情/纯符号"""
    if not text_str:
        return True
    s = text_str.strip().lower()
    if not s:
        return True
    if s in _GREETING_WORDS:
        return True
    if len(s) <= 3:
        return True
    return False


def should_skip_no_reply_alert(db_module, peer_id, account_id):
    """判断要不要跳过这次未回复预警。
    规则：若对方只发了 1 条且是寒暄/表情/图片 -> 跳过
    """
    try:
        conn = db_module.get_conn()
        last_a = conn.execute(
            "SELECT timestamp FROM messages WHERE peer_id=? AND account_id=? AND direction='A' AND deleted=0 ORDER BY timestamp DESC LIMIT 1",
            (peer_id, account_id)
        ).fetchone()
        last_a_ts = last_a["timestamp"] if last_a else "1970-01-01 00:00:00"
        rows = conn.execute(
            "SELECT text, media_type FROM messages WHERE peer_id=? AND account_id=? AND direction='B' AND deleted=0 AND timestamp > ? ORDER BY timestamp ASC",
            (peer_id, account_id, last_a_ts)
        ).fetchall()
        if len(rows) == 0:
            return True
        if len(rows) >= 2:
            return False
        row = rows[0]
        media = row["media_type"] if "media_type" in row.keys() else None
        if media:
            return True
        return _is_greeting_or_emoji(row["text"])
    except Exception:
        return False
