"""TG Bot — 预警推送 + 审核按钮"""
import json
import logging
import asyncio
import os
from aiogram import Bot, Dispatcher, F
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery

import config
import database as db
import templates

# YYZL v2.11: 中心智能分发
try:
    from center_router import route_to_group
except ImportError:
    route_to_group = None

logger = logging.getLogger(__name__)


def _suffix_for_rule(rule: str) -> str:
    """转发媒体时的临时文件扩展名"""
    return {
        "photo": ".jpg",
        "video": ".mp4",
        "voice": ".ogg",
        "file":  ".bin",
    }.get(rule, ".bin")


class AlertBot:
    def __init__(self, sheets_writer=None):
        self.sheets = sheets_writer
        if not config.BOT_TOKEN:
            logger.warning("BOT_TOKEN 未设置，Bot 功能暂时关闭")
            self.bot = None
            self.dp = None
            return

        self.bot = Bot(token=config.BOT_TOKEN)
        self.dp = Dispatcher()
        self._register_handlers()


    def _get_group_id_for_peer(self, peer, kind: str = "no_reply"):
        """v4 YYZL: 根据外事号所属中心,智能路由到对应群

        参数:
            peer: peer 字典或 sqlite3.Row
            kind: 'no_reply' (怠工) / 'risk' (风控) / 'archive' (档案)
        """
        try:
            if route_to_group:
                peer_name = ""
                try:
                    peer_name = peer.get("name", "") if hasattr(peer, "get") else peer["name"]
                except Exception:
                    peer_name = ""
                if peer_name:
                    group_id, _info = route_to_group(peer_name, kind=kind)
                    if group_id:
                        return group_id
        except Exception as e:
            logger.warning(f"[中心路由] 失败,使用默认群: {e}")
        return config.ALERT_GROUP_ID

    def _get_peer_routing_info(self, peer):
        """拿外事号在 Sheet 里的归属信息"""
        try:
            if route_to_group:
                peer_name = ""
                try:
                    peer_name = peer.get("name", "") if hasattr(peer, "get") else peer["name"]
                except Exception:
                    peer_name = ""
                if peer_name:
                    _gid, info = route_to_group(peer_name, kind="no_reply")
                    return info
        except Exception as e:
            logger.warning(f"[中心路由 info] 失败: {e}")
        return {"中心": "", "公司": "", "花名": "", "监察员": "", "matched": False}

    def _has_any_alert_group(self):
        """v4: 任意一个中心群配了就算可推送"""
        if config.ALERT_GROUP_ID:
            return True
        try:
            from center_router import get_center_groups
            for kind in ("no_reply", "risk", "archive"):
                for gid in get_center_groups(kind=kind).values():
                    if gid:
                        return True
        except Exception:
            pass
        return False

    def _register_handlers(self):
        @self.dp.message(F.text == "/start")
        async def on_start(message):
            await message.reply(
                "👋 这是 TG 监控的预警 Bot。\n"
                "如果你要绑定账号做密码找回,请在网页设置页获取绑定码,\n"
                "然后发 /bind BIND-XXXXXX"
            )

        @self.dp.message(F.text.startswith("/bind"))
        async def on_bind(message):
            if message.chat.type != "private":
                await message.reply("请私聊我发送此指令。")
                return
            parts = message.text.strip().split(maxsplit=1)
            if len(parts) != 2:
                await message.reply("用法: /bind BIND-XXXXXX")
                return
            code = parts[1].strip().upper()
            import auth_reset
            tg_user_id = message.from_user.id
            tg_username = (message.from_user.username
                           or message.from_user.full_name
                           or str(tg_user_id))
            bound_user = auth_reset.try_complete_bind(code, tg_user_id, tg_username)
            if bound_user:
                await message.reply(
                    f"✅ 已绑定到帐号 {bound_user}\n"
                    "以后忘记密码可在登入页点「忘记密码」通过我私信收到验证码。"
                )
            else:
                await message.reply("❌ 绑定码无效或已过期。请回网页刷新获取新绑定码。")

        @self.dp.message(F.text == "/sync_daily")
        async def on_sync_daily(message):
            """手动触发每日数据写入 - v3.1 调试版
            权限: 仅群管理员可触发
            """
            # 详细日志,方便排查
            chat_id = message.chat.id
            chat_type = str(message.chat.type)
            user_id = message.from_user.id
            logger.info(f"[/sync_daily] 收到命令 chat_id={chat_id} type={chat_type} user_id={user_id}")
            # 1. 私聊不响应,但其他都响应(先放宽,确认能跑通再收紧)
            if "private" in chat_type.lower():
                logger.info("[/sync_daily] 私聊,跳过")
                return
            # 2. 检查发命令的人是否是群管理员
            try:
                member = await self.bot.get_chat_member(chat_id, user_id)
                logger.info(f"[/sync_daily] 用户角色: {member.status}")
                if str(member.status) not in ("ChatMemberStatus.CREATOR", "ChatMemberStatus.ADMINISTRATOR", "creator", "administrator"):
                    await message.reply(f"❌ 仅群管理员可触发 (你的角色: {member.status})")
                    return
            except Exception as e:
                logger.error(f"[/sync_daily] 权限检查失败: {e}", exc_info=True)
                await message.reply(f"❌ 权限检查失败: {e}")
                return
            # 3. 从 config 读取(不用 os.environ)
            try:
                import config
                sheet_id = getattr(config, "DAILY_SHEET_ID", "") or ""
                sheet_gid = getattr(config, "DAILY_SHEET_GID", "") or ""
            except Exception as e:
                await message.reply(f"❌ 读取配置失败: {e}")
                return
            if not sheet_id or not sheet_gid:
                await message.reply(f"❌ 配置缺失: SHEET_ID={bool(sheet_id)} GID={bool(sheet_gid)}")
                return
            # 4. 触发同步
            await message.reply("⏳ 正在同步每日数据,请稍候...")
            try:
                from daily_data_writer import run_daily_sync
                success, msg = run_daily_sync(sheet_id, sheet_gid)
                if success:
                    await message.reply(f"✅ 同步完成: {msg}")
                else:
                    await message.reply(f"⚠️ 同步未完成: {msg}")
            except Exception as e:
                logger.error(f"[/sync_daily] 同步异常", exc_info=True)
                await message.reply(f"❌ 同步异常: {e}")

        @self.dp.callback_query(F.data.startswith("approve:") | F.data.startswith("reject:"))
        async def on_audit(callback: CallbackQuery):
            data = callback.data
            action, alert_id_str = data.split(":", 1)
            alert_id = int(alert_id_str)

            alert = db.get_alert(alert_id)
            if not alert:
                await callback.answer("预警不存在")
                return

            if alert["status"] != "pending":
                await callback.answer("已处理过了")
                return

            if action == "approve":
                db.update_alert_status(alert_id, "approved")
                # 写入对应的预警分表
                self._write_alert_to_sheet(alert)
                # 更新消息，去掉按钮
                await callback.message.edit_text(
                    callback.message.text + "\n\n✅ 已通过 — " + (callback.from_user.full_name or ""),
                )
                await callback.answer("已通过")
            else:
                db.update_alert_status(alert_id, "rejected")
                await callback.message.edit_text(
                    callback.message.text + "\n\n❌ 已拒绝 — " + (callback.from_user.full_name or ""),
                )
                await callback.answer("已拒绝")

    def _make_keyboard(self, alert_id):
        return InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="通过", callback_data=f"approve:{alert_id}"),
                InlineKeyboardButton(text="拒绝", callback_data=f"reject:{alert_id}"),
            ]
        ])

    def _write_alert_to_sheet(self, alert):
        """审核通过后写入预警分表"""
        if not self.sheets:
            return
        for attempt in range(3):
            try:
                account = db.get_conn().execute(
                    "SELECT * FROM accounts WHERE id=?", (alert["account_id"],)
                ).fetchone()
                peer = db.get_conn().execute(
                    "SELECT * FROM peers WHERE id=?", (alert["peer_id"],)
                ).fetchone() if alert["peer_id"] else None

                company = account["company"] if account else ""
                operator = account["operator"] if account else ""
                account_name = account["name"] if account else ""
                peer_name = peer["name"] if peer else ""
                now = db.now_bj()

                with self.sheets._write_lock:
                    if alert["type"] == "no_reply":
                        ws = self.sheets.spreadsheet.worksheet(f"信息未回复预警{config.COMPANY_DISPLAY}")
                        self.sheets._rate_limit()
                        ws.append_row([company, operator, account_name, peer_name, alert["message_text"], now])
                    elif alert["type"] == "deleted":
                        ws = self.sheets.spreadsheet.worksheet(f"信息删除预警{config.COMPANY_DISPLAY}")
                        self.sheets._rate_limit()
                        # 第 5 列写入"删除前消息内容"方便主管看板回溯
                        ws.append_row([company, operator, account_name, peer_name,
                                       alert["message_text"] or "", now])
                return
            except Exception as e:
                logger.error("写入预警分表失败 (尝试 %d/3): %s", attempt + 1, e)
                if attempt < 2:
                    import time; time.sleep(2)

    async def send_keyword_alert(self, account_id, peer, keyword, text):
        """发送敏感词预警 — v3 推风控群"""
        if not self.bot or not self._has_any_alert_group():
            return
        if db.has_alert_today("keyword", peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        peer_name = peer["name"] if "name" in peer.keys() else ""

        msg = templates.risk_alert(
            rule="keyword",
            center=center,
            company=company,
            person=person,
            peer_name=peer_name,
            extra_content=text,
            keyword=keyword,
        )
        try:
            config.reload_if_env_changed()
            if config.ALERT_KEYWORD_ENABLED:
                _gid = self._get_group_id_for_peer(peer, kind="risk")
                await self.bot.send_message(_gid, msg)
            else:
                logger.info("[ALERT_KEYWORD_DISABLED] 跳过关键词推送 peer=%s keyword=%s (Sheet 仍写入)", peer["id"], keyword)
            # 写入关键词监听分表
            if self.sheets:
                for attempt in range(3):
                    try:
                        with self.sheets._write_lock:
                            ws = self.sheets.spreadsheet.worksheet(f"关键词监听{config.COMPANY_DISPLAY}")
                            self.sheets._rate_limit()
                            ws.append_row([
                                account["company"], account["operator"], account["name"],
                                peer["name"], keyword, text, db.now_bj()
                            ])
                        break
                    except Exception as e2:
                        logger.error("写入关键词分表失败 (尝试 %d/3): %s", attempt + 1, e2)
                        if attempt < 2:
                            import time; time.sleep(2)
            db.insert_alert("keyword", account_id, peer["id"], message_text=f"[{keyword}] {text}")
        except Exception as e:
            logger.error("发送关键词预警失败: %s", e)

    async def send_no_reply_alert(self, account_id, peer, message_text, msg_id):
        """发送怠工/未回复预警(每个广告主每天只推一次)— v3 新格式"""
        if not self.bot or not self._has_any_alert_group():
            return
        if db.has_alert_today("no_reply", peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        # 创建预警记录
        alert_id = db.insert_alert(
            alert_type="no_reply",
            account_id=account_id,
            peer_id=peer["id"],
            msg_id=msg_id,
            message_text=message_text,
        )

        # v3: 从 Sheet 路由信息拿中心/公司/花名(优先于 account 表)
        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        peer_name = peer["name"] if "name" in peer.keys() else ""

        msg = templates.no_reply_alert(
            center=center,
            company=company,
            person=person,
            peer_name=peer_name,
            no_reply_minutes=config.NO_REPLY_MINUTES,
            count=1,
        )
        # 推送总开关检查
        config.reload_if_env_changed()
        if not config.ALERT_NO_REPLY_ENABLED:
            logger.info("[ALERT_NO_REPLY_DISABLED] 跳过未回复推送 peer=%s (alerts 已记录)", peer["id"])
            return
        try:
            _gid = self._get_group_id_for_peer(peer, kind="no_reply")
            sent = await self.bot.send_message(
                _gid, msg,
                reply_markup=self._make_keyboard(alert_id),
            )
            db.update_alert_bot_msg(alert_id, sent.message_id)
        except Exception as e:
            logger.error("发送未回复预警失败: %s", e)

    async def send_delete_alert(self, account_id, peer, message_text, msg_id,
                                direction: str = ""):
        """发送删除消息预警 — v3 推风控群
        
        参数:
            direction: 'A' = 外事号自己发的(被自己删 → 我方删除)
                       'B' = 对方发的(被对方撤回 → 对方撤回消息)
                       ''  = 兼容旧调用,默认按对方撤回
        """
        if not self.bot or not self._has_any_alert_group():
            return
        if db.has_alert_today("deleted", peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        alert_id = db.insert_alert(
            alert_type="deleted",
            account_id=account_id,
            peer_id=peer["id"],
            msg_id=msg_id,
            message_text=message_text,
        )

        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        peer_name = peer["name"] if "name" in peer.keys() else ""

        # v3: 根据 direction 选 rule
        if direction == "A":
            rule = "self_del"   # 我方删除对话
        else:
            rule = "deleted"    # 对方撤回消息

        msg = templates.risk_alert(
            rule=rule,
            center=center,
            company=company,
            person=person,
            peer_name=peer_name,
            extra_content=message_text or "",
        )
        config.reload_if_env_changed()
        if not config.ALERT_DELETE_ENABLED:
            logger.info("[ALERT_DELETE_DISABLED] 跳过删除推送 peer=%s (alerts 已记录)", peer["id"])
            return
        try:
            _gid = self._get_group_id_for_peer(peer, kind="risk")
            sent = await self.bot.send_message(
                _gid, msg,
                reply_markup=self._make_keyboard(alert_id),
            )
            db.update_alert_bot_msg(alert_id, sent.message_id)
        except Exception as e:
            logger.error("发送删除预警失败: %s", e)

    async def send_risk_alert(self, account_id, peer, rule: str, msg_obj=None,
                              text="", keyword=""):
        """v4 通用风控/档案预警 — 按 rule 路由到 风控群 或 档案群

        路由规则:
            - keyword (敏感词)            → 风控群 (RISK)
            - self_del (我方删除)         → 风控群 (RISK)
            - deleted (对方撤回)          → 风控群 (RISK)
            - photo/video/voice/file/link → 档案群 (ARCHIVE)
        """
        if not self.bot or not self._has_any_alert_group():
            return

        # 决定路由类别
        if rule in ("keyword", "self_del", "deleted"):
            route_kind = "risk"
        elif rule in ("photo", "video", "voice", "file", "link"):
            route_kind = "archive"
        else:
            logger.warning("[risk-%s] 未知规则,忽略", rule)
            return

        # 同 peer + 同 rule 当天只推一次
        dedupe_key = f"risk_{rule}"
        if db.has_alert_today(dedupe_key, peer["id"]):
            return

        account = db.get_conn().execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not account:
            return

        alert_id = db.insert_alert(
            alert_type=dedupe_key,
            account_id=account_id,
            peer_id=peer["id"],
            msg_id=getattr(msg_obj, "id", 0) if msg_obj else 0,
            message_text=(text or keyword or rule)[:500],
        )

        info = self._get_peer_routing_info(peer)
        center = info.get("中心") or ""
        company = info.get("公司") or ""
        person = info.get("花名") or (account["operator"] if account else "")
        peer_name = peer["name"] if "name" in peer.keys() else ""

        # 用对应的模板函数
        if route_kind == "risk":
            msg = templates.risk_alert(
                rule=rule, center=center, company=company,
                person=person, peer_name=peer_name,
                extra_content=text or "", keyword=keyword,
            )
        else:  # archive
            msg = templates.archive_alert(
                rule=rule, center=center, company=company,
                person=person, peer_name=peer_name,
                extra_content=text or "",
            )

        # 检查总开关
        config.reload_if_env_changed()
        if rule == "keyword" and not config.ALERT_KEYWORD_ENABLED:
            logger.info("[ALERT_KEYWORD_DISABLED] 跳过风控-敏感词推送")
            return
        risk_enabled = os.environ.get("ALERT_RISK_ENABLED", "true").strip().lower()
        archive_enabled = os.environ.get("ALERT_ARCHIVE_ENABLED", "true").strip().lower()
        if route_kind == "risk" and risk_enabled in ("false", "0", "no"):
            logger.info("[ALERT_RISK_DISABLED] 跳过风控-%s 推送", rule)
            return
        if route_kind == "archive" and archive_enabled in ("false", "0", "no"):
            logger.info("[ALERT_ARCHIVE_DISABLED] 跳过档案-%s 推送", rule)
            return

        try:
            _gid = self._get_group_id_for_peer(peer, kind=route_kind)
            sent = await self.bot.send_message(_gid, msg)
            db.update_alert_bot_msg(alert_id, sent.message_id)

            # 转发原媒体(图片/视频/语音/文件)到同一档案群
            if msg_obj is not None and rule in ("photo", "video", "voice", "file"):
                try:
                    await self._forward_media_via_download(_gid, msg_obj, rule)
                except Exception as e:
                    logger.warning("[archive-%s] 转发媒体失败: %s", rule, e)
        except Exception as e:
            logger.error("[%s-%s] 发送预警失败: %s", route_kind, rule, e)

    async def _forward_media_via_download(self, group_id: int, msg_obj, rule: str):
        """把 Telethon Message 的媒体下载到本地,再用 aiogram 上传到群。

        注意:msg_obj 是 Telethon Message,client 是 listener 那边的 TelegramClient,
        我们从 msg_obj.client 拿。
        """
        import tempfile
        from aiogram.types import FSInputFile
        client = getattr(msg_obj, "_client", None) or getattr(msg_obj, "client", None)
        if client is None:
            logger.warning("[forward] msg_obj 无 client,跳过")
            return
        # 下载到临时文件
        with tempfile.NamedTemporaryFile(delete=False, suffix=_suffix_for_rule(rule)) as tmp:
            tmp_path = tmp.name
        try:
            await client.download_media(msg_obj, file=tmp_path)
            f = FSInputFile(tmp_path)
            if rule == "photo":
                await self.bot.send_photo(group_id, photo=f)
            elif rule == "video":
                await self.bot.send_video(group_id, video=f)
            elif rule == "voice":
                await self.bot.send_voice(group_id, voice=f)
            elif rule == "file":
                await self.bot.send_document(group_id, document=f)
        finally:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass

    async def send_daily_report(self):
        """发送每日总结"""
        if not self.bot or not config.ALERT_GROUP_ID:
            return
        # v2.6.2: 日报独立开关
        config.reload_if_env_changed()
        if not config.DAILY_REPORT_ENABLED:
            logger.info("[DAILY_REPORT_DISABLED] 跳过日报推送")
            return

        from database import TZ_BJ
        from datetime import datetime

        now = datetime.now(TZ_BJ).strftime("%Y-%m-%d %H:%M:%S")

        # 统计昨天的数据（00:00 发送时统计前一天）
        from datetime import timedelta
        yesterday = (datetime.now(TZ_BJ) - timedelta(days=1)).strftime("%Y-%m-%d")
        conn = db.get_conn()

        chat_count = conn.execute(
            "SELECT COUNT(DISTINCT peer_id) FROM messages WHERE timestamp LIKE ?",
            (f"{yesterday}%",)
        ).fetchone()[0]

        def _status_breakdown(type_name):
            rows = conn.execute(
                "SELECT status, COUNT(*) FROM alerts WHERE type=? AND created_at LIKE ? GROUP BY status",
                (type_name, f"{yesterday}%")
            ).fetchall()
            bucket = {"approved": 0, "pending": 0, "rejected": 0}
            for status, cnt in rows:
                if status in bucket:
                    bucket[status] = cnt
            return bucket

        no_reply_detail = _status_breakdown("no_reply")
        no_reply = sum(no_reply_detail.values())

        delete_detail = _status_breakdown("deleted")
        deleted = sum(delete_detail.values())

        keyword_count = conn.execute(
            "SELECT COUNT(*) FROM alerts WHERE type='keyword' AND created_at LIKE ?",
            (f"{yesterday}%",)
        ).fetchone()[0]

        msg = templates.daily_report(
            yesterday, now, chat_count, no_reply, deleted, keyword_count,
            no_reply_detail=no_reply_detail, delete_detail=delete_detail,
        )
        try:
            await self.bot.send_message(config.ALERT_GROUP_ID, msg)
            logger.info("日报已推送")
        except Exception as e:
            logger.error("发送日报失败: %s", e)

    async def send_session_alert(self, kind: str, phone: str, account_id: int = 0, account_name: str = ""):
        """v2.10.4: 推送 session 吊销/恢复预警。kind: 'revoked' | 'restored'
        - 走主开关 ALERTS_ENABLED(任何子开关都独立;这是系统级告警)
        - DB 写 alerts 表,实时告警流会显示
        - kind='revoked' 直接推;kind='restored' 也推一条,让客户知道已恢复"""
        if not self.bot or not config.ALERT_GROUP_ID:
            logger.warning("[session_%s] bot 未配或未配预警群,不推送 phone=%s", kind, phone)
            return
        try:
            config.reload_if_env_changed()
            if kind == "revoked":
                msg = templates.session_revoked_alert(phone, account_name)
                alert_type = "session_revoked"
            elif kind == "restored":
                msg = templates.session_restored_alert(phone, account_name)
                alert_type = "session_restored"
            else:
                return
            # DB 记录(不受 ALERTS_ENABLED 影响,审计留痕)
            try:
                if account_id:
                    db.insert_alert(alert_type, account_id, peer_id=None, message_text=f"[{phone}] {account_name}")
            except Exception as e:
                logger.warning("[session_%s] insert_alert 失败: %s", kind, e)
            # v2.10.5: 运维告警,永远推 — 不受 ALERTS_ENABLED 影响
            # (ALERTS_ENABLED 只管业务告警:关键词/未回复/删除。session 吊销是系统性故障,必须让客户知道)
            await self.bot.send_message(config.ALERT_GROUP_ID, msg)
            logger.info("[session_%s] 已推送 phone=%s", kind, phone)
        except Exception as e:
            logger.error("[session_%s] 推送失败 phone=%s: %s", kind, phone, e)

    async def send_update_notice(self, state: dict):
        """v2.9.0: 发现 GitHub 有新版 → 推送到预警群(同版本只推一次,update_checker 控制去重)"""
        if not self.bot or not config.ALERT_GROUP_ID:
            return

        new_commits = state.get("new_commits", [])
        latest_title = state.get("latest_user_title") or "📦 有新版本可升级"
        latest_body = state.get("latest_user_body") or ""

        company = getattr(config, "COMPANY_NAME", "")
        company_display = getattr(config, "COMPANY_DISPLAY", company)

        lines = [f"<b>{latest_title}</b>", "", f"部门:{company_display}"]
        if latest_body:
            lines.append("")
            lines.append(latest_body)

        # 如果中间跨了多个版本,把每个版本的白话也列出来
        if len(new_commits) > 1:
            lines.append("")
            lines.append(f"<b>本次更新涵盖 {len(new_commits)} 个版本:</b>")
            for c in new_commits[-6:]:
                t = c.get("user_title", "") or "更新"
                b = c.get("user_body", "")
                lines.append(f"  {t}")
                if b:
                    lines.append(f"    {b}")
            if len(new_commits) > 6:
                lines.append(f"  ...(还有 {len(new_commits)-6} 个,登入管理页看完整列表)")

        lines.append("")
        lines.append("<b>如何升级</b>(复制这行到服务器跑):")
        lines.append(f"<code>cd /root/tg-monitor-{company} && bash update.sh</code>")
        lines.append("")
        lines.append("✓ 有回滚保护,万一有问题会自动退回旧版")
        lines.append("✓ 升级期间网页会短暂刷新,大约 30 秒恢复")

        msg = "\n".join(lines)
        try:
            await self.bot.send_message(
                config.ALERT_GROUP_ID, msg,
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            _short = state.get("latest_short", "")
            logger.info(f"版本更新通知已推送: {_short}")
        except Exception as e:
            logger.error(f"版本更新通知推送失败: {e}")

    async def start(self):
        """启动 Bot 轮询"""
        if not self.dp:
            return
        logger.info("Bot 启动...")
        await self.dp.start_polling(self.bot)
