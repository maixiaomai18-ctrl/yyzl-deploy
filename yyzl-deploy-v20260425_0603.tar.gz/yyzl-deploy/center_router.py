"""
中心路由模块
根据外事号昵称，决定预警推送到哪个中心群
"""
import os
from pathlib import Path
try:
    from dotenv import load_dotenv
    _env_path = Path(__file__).parent / ".env"
    if _env_path.exists():
        load_dotenv(_env_path, override=True)
except ImportError:
    pass  # dotenv 未安装，依赖 docker-compose 注入
import logging
from daily_sheet_sync import get_peer_info, load_cache

logger = logging.getLogger(__name__)

# 4 个中心对应的预警群 ID（从 .env 读）
def _get_int(key, default=0):
    v = os.environ.get(key, "").strip()
    try:
        return int(v) if v else default
    except ValueError:
        return default


# 中心 → 群 ID 映射
def get_center_groups():
    """每次调用都重新读 env（支持热更新）"""
    return {
        "商务中心": _get_int("ALERT_GROUP_SHANGWU"),
        "渠道中心": _get_int("ALERT_GROUP_QUDAO"),
        "运营中心": _get_int("ALERT_GROUP_YUNYING"),
        "恒丰公司": _get_int("ALERT_GROUP_HENGFENG"),
    }


def get_default_group():
    """兜底群（匹配不到时用原 ALERT_GROUP_ID）"""
    return _get_int("ALERT_GROUP_ID")


def route_to_group(peer_name):
    """
    根据外事号昵称，返回应该推送的群 ID
    
    参数:
        peer_name: 外事号昵称（如"张心姿"）
    
    返回:
        (group_id, match_info)
        - group_id: int 群 ID
        - match_info: dict 匹配信息（用于日志和消息模板）
    """
    info = get_peer_info(peer_name)
    
    if not info:
        # 没找到，用默认群
        default_gid = get_default_group()
        logger.warning(f"[路由] 未找到「{peer_name}」的映射，使用默认群 {default_gid}")
        return default_gid, {
            "matched": False,
            "中心": "未知",
            "公司": "未知",
            "花名": "未知",
            "监察员": "未知",
        }
    
    center = info.get("中心", "")
    groups = get_center_groups()
    group_id = groups.get(center, 0)
    
    if group_id == 0:
        # 中心找到了但群 ID 没配置
        default_gid = get_default_group()
        logger.warning(
            f"[路由] 「{peer_name}」所属「{center}」，但 ALERT_GROUP_{center} 未配置，"
            f"使用默认群 {default_gid}"
        )
        return default_gid, {**info, "matched": True}
    
    logger.info(f"[路由] 「{peer_name}」→ {center} 群 ({group_id})")
    return group_id, {**info, "matched": True}


def get_supervisor_for_peer(peer_name):
    """
    获取外事号的监察员（用于消息模板）
    
    返回:
        str: 监察员名字（"麦小麦"/"季霖"/"吴苍河"/"陈家碧"）或 None
    """
    info = get_peer_info(peer_name)
    if info:
        return info.get("监察员")
    return None


def get_vps_code():
    """获取当前 VPS 的标识（如"麦小麦1"）"""
    return os.environ.get("VPS_CODE", "").strip()


def get_operator_name():
    """获取当前 VPS 的监察员名（如"麦小麦"）"""
    return os.environ.get("OPERATOR_NAME", "").strip()


if __name__ == "__main__":
    # 测试路由功能
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    
    print("=== 配置检查 ===")
    print(f"VPS_CODE: {get_vps_code() or '(未设置)'}")
    print(f"OPERATOR_NAME: {get_operator_name() or '(未设置)'}")
    print(f"默认群: {get_default_group()}")
    print(f"中心群映射:")
    for k, v in get_center_groups().items():
        status = "✅" if v else "❌未配置"
        print(f"  {k}: {v} {status}")
    
    print(f"\n=== 缓存检查 ===")
    cache = load_cache()
    if cache:
        print(f"  总外事号: {len(cache.get('mapping', {}))}")
        print(f"  更新时间: {cache.get('updated_at')}")
    else:
        print(f"  ❌ 缓存不存在，请先跑 python3 daily_sheet_sync.py")
    
    print(f"\n=== 路由测试 ===")
    test_cases = [
        "张心姿",        # 商务中心
        "小叛逆",        # 运营中心（麦小麦 Tab 的）
        "小王【持续收量】",  # 渠道中心
        "哆哔",          # 恒丰公司
        "不存在的号",     # 兜底
    ]
    for peer in test_cases:
        gid, info = route_to_group(peer)
        matched = "✅" if info.get("matched") else "❌"
        center = info.get("中心", "未知")
        supervisor = info.get("监察员", "未知")
        print(f"  {matched} 「{peer}」→ {center} / 监察员={supervisor} / 群={gid}")
