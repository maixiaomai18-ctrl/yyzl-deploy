"""中心路由模块 — v4 (3 群: 怠工/风控/档案)"""
import os
import logging
from pathlib import Path
try:
    from dotenv import load_dotenv
    _env_path = Path(__file__).parent / ".env"
    if _env_path.exists():
        load_dotenv(_env_path, override=True)
except ImportError:
    pass
from daily_sheet_sync import get_peer_info, load_cache

logger = logging.getLogger(__name__)


# 默认 4 个中心 → env key 后缀映射
DEFAULT_CENTER_KEY = {
    "商务中心": "SHANGWU",
    "渠道中心": "QUDAO",
    "运营中心": "YUNYING",
    "恒丰公司": "HENGFENG",
    "恒丰中心": "HENGFENG",
}

# 群类型 → env 前缀
GROUP_KIND_PREFIX = {
    "no_reply": "ALERT_GROUP_",         # 怠工群
    "risk":     "ALERT_RISK_GROUP_",    # 风控群
    "archive":  "ALERT_ARCHIVE_GROUP_", # 档案群
}


def _get_int(key, default=0):
    v = os.environ.get(key, "").strip()
    try:
        return int(v) if v else default
    except ValueError:
        return default


def _center_key(center_zh: str) -> str:
    custom = os.environ.get(f"CENTER_KEY_{center_zh}", "").strip()
    if custom:
        return custom
    return DEFAULT_CENTER_KEY.get(center_zh, "")


def get_center_groups(kind: str = "no_reply") -> dict:
    """所有中心的某类预警群 ID 映射

    参数:
        kind: 'no_reply' (怠工) / 'risk' (风控) / 'archive' (档案)

    返回:
        {中文中心名: group_id, ...}
    """
    prefix = GROUP_KIND_PREFIX.get(kind, "ALERT_GROUP_")
    result = {}
    # 默认 4 个中心
    for zh, key in DEFAULT_CENTER_KEY.items():
        result[zh] = _get_int(prefix + key)
    # 扩展中心 (CENTERS_EXT=金融中心:JINRONG,xxx:YYY)
    ext = os.environ.get("CENTERS_EXT", "").strip()
    if ext:
        for entry in ext.split(","):
            entry = entry.strip()
            if not entry or ":" not in entry:
                continue
            zh, key = entry.split(":", 1)
            zh = zh.strip()
            key = key.strip()
            if not zh or not key:
                continue
            os.environ.setdefault(f"CENTER_KEY_{zh}", key)
            result[zh] = _get_int(prefix + key)
    return result


def get_default_group():
    return _get_int("ALERT_GROUP_ID")


def route_to_group(peer_name: str, kind: str = "no_reply"):
    """根据外事号别名,返回应该推送的群 ID + peer 信息

    参数:
        peer_name: 外事号别名
        kind:      群类型 ('no_reply' / 'risk' / 'archive')

    返回:
        (group_id, info)
    """
    info = get_peer_info(peer_name) or {}
    if not info:
        default_gid = get_default_group()
        logger.warning(f"[路由] 未找到「{peer_name}」的映射, 使用默认群 {default_gid}")
        return default_gid, {
            "matched": False,
            "中心": "未知",
            "公司": "未知",
            "花名": os.environ.get("OPERATOR_NAME", "未知"),
            "监察员": os.environ.get("OPERATOR_NAME", "未知"),
        }

    center = info.get("中心", "")
    groups = get_center_groups(kind=kind)
    group_id = groups.get(center, 0)

    if group_id == 0:
        default_gid = get_default_group()
        logger.warning(
            f"[路由] 「{peer_name}」所属「{center}」, 但 {kind}群未配置, 使用默认群 {default_gid}"
        )
        return default_gid, {**info, "matched": True}

    logger.info(f"[路由] 「{peer_name}」→ {center} {kind}群 ({group_id})")
    return group_id, {**info, "matched": True}


def get_supervisor_for_peer(peer_name):
    info = get_peer_info(peer_name)
    if info:
        return info.get("监察员")
    return None


def get_vps_code():
    return os.environ.get("VPS_CODE", "").strip()


def get_operator_name():
    return os.environ.get("OPERATOR_NAME", "").strip()


def get_supervisor_label():
    op = get_operator_name()
    num = os.environ.get("VPS_NUM", "").strip()
    if op and num:
        return f"{op}{num}"
    code = get_vps_code()
    if code:
        import re
        m = re.search(r"(\D+?)-?(\d+)", code)
        if m:
            return f"{m.group(1)}{m.group(2)}"
    return op or "未知"


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    print("=== 配置检查 ===")
    print(f"VPS_CODE: {get_vps_code() or '(未设置)'}")
    print(f"OPERATOR_NAME: {get_operator_name() or '(未设置)'}")
    print(f"监察人员标签: {get_supervisor_label()}")
    print(f"TG_USERNAME: {os.environ.get('TG_USERNAME', '(未设置)')}")
    print(f"默认群: {get_default_group()}")
    for kind in ("no_reply", "risk", "archive"):
        kind_label = {"no_reply": "怠工", "risk": "风控", "archive": "档案"}[kind]
        print(f"\n{kind_label}群:")
        for k, v in get_center_groups(kind=kind).items():
            status = "✅" if v else "❌未配置"
            print(f"  {k}: {v} {status}")
