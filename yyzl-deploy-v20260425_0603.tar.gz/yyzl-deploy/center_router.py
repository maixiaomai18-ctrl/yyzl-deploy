"""
中心路由模块 — v3 (加风控群路由)

根据外事号别名,决定预警推送到哪个中心的哪个群:
    - 怠工预警 → ALERT_GROUP_<center>
    - 风控预警 → ALERT_RISK_GROUP_<center>

中心列表从 .env 的 CENTERS 读(逗号分隔),默认 4 个固定。
未来加新中心 → Web 后台『中心管理』页 → 写 CENTERS + 对应 ALERT_GROUP_*
"""
import os
import logging
from pathlib import Path
try:
    from dotenv import load_dotenv
    _env_path = Path(__file__).parent / ".env"
    if _env_path.exists():
        load_dotenv(_env_path, override=True)
except ImportError:
    pass
from daily_sheet_sync import get_peer_info, load_cache

logger = logging.getLogger(__name__)


# 默认 4 个中心 → env key 后缀映射
# 后缀可被『中心管理』页扩展,写入 .env CENTER_KEY_<中文中心名>=<拼音后缀>
DEFAULT_CENTER_KEY = {
    "商务中心": "SHANGWU",
    "渠道中心": "QUDAO",
    "运营中心": "YUNYING",
    "恒丰公司": "HENGFENG",
    "恒丰中心": "HENGFENG",
}


def _get_int(key, default=0):
    v = os.environ.get(key, "").strip()
    try:
        return int(v) if v else default
    except ValueError:
        return default


def _center_key(center_zh: str) -> str:
    """从 .env 读 CENTER_KEY_<中文中心名> 后缀,默认用 DEFAULT_CENTER_KEY 兜底
    例: '商务中心' → 'SHANGWU' → ALERT_GROUP_SHANGWU
    """
    custom = os.environ.get(f"CENTER_KEY_{center_zh}", "").strip()
    if custom:
        return custom
    return DEFAULT_CENTER_KEY.get(center_zh, "")


def get_center_groups(risk: bool = False) -> dict:
    """所有中心的怠工/风控群 ID 映射

    参数:
        risk: True = 风控群 (ALERT_RISK_GROUP_*), False = 怠工群 (ALERT_GROUP_*)

    返回:
        {中文中心名: group_id, ...}
    """
    prefix = "ALERT_RISK_GROUP_" if risk else "ALERT_GROUP_"
    result = {}
    # 1) DEFAULT_CENTER_KEY 里的中心(永远列出来,即使没配)
    for zh, key in DEFAULT_CENTER_KEY.items():
        result[zh] = _get_int(prefix + key)
    # 2) Web 后台扩展的中心 (CENTERS_EXT=金融中心:JINRONG,xxx:YYY)
    ext = os.environ.get("CENTERS_EXT", "").strip()
    if ext:
        for entry in ext.split(","):
            entry = entry.strip()
            if not entry or ":" not in entry:
                continue
            zh, key = entry.split(":", 1)
            zh = zh.strip()
            key = key.strip()
            if not zh or not key:
                continue
            # 同时写 CENTER_KEY_<zh>=key,方便其他模块查
            os.environ.setdefault(f"CENTER_KEY_{zh}", key)
            result[zh] = _get_int(prefix + key)
    return result


def get_default_group():
    """兜底群"""
    return _get_int("ALERT_GROUP_ID")


def route_to_group(peer_name: str, risk: bool = False):
    """
    根据外事号别名,返回应该推送的群 ID + 完整 peer 信息

    参数:
        peer_name: 外事号别名(如『悦悦-【官方收量】』)
        risk:      True = 风控群,False = 怠工群

    返回:
        (group_id, info)
        - group_id: int 群 ID(0 表示没配)
        - info: dict {中心, 公司, 花名, 监察员, matched}
    """
    info = get_peer_info(peer_name) or {}
    if not info:
        # 未在 Sheet 里登记 → 用归属人默认名兜底,推默认群(若有)
        default_gid = get_default_group()
        logger.warning(f"[路由] 未找到「{peer_name}」的映射,使用默认群 {default_gid}")
        return default_gid, {
            "matched": False,
            "中心": "未知",
            "公司": "未知",
            "花名": os.environ.get("OPERATOR_NAME", "未知"),  # 用监察员名作 fallback
            "监察员": os.environ.get("OPERATOR_NAME", "未知"),
        }

    center = info.get("中心", "")
    groups = get_center_groups(risk=risk)
    group_id = groups.get(center, 0)

    if group_id == 0:
        default_gid = get_default_group()
        kind = "风控" if risk else "怠工"
        logger.warning(
            f"[路由] 「{peer_name}」所属「{center}」,但 {kind}群未配置,使用默认群 {default_gid}"
        )
        return default_gid, {**info, "matched": True}

    kind = "风控" if risk else "怠工"
    logger.info(f"[路由] 「{peer_name}」→ {center} {kind}群 ({group_id})")
    return group_id, {**info, "matched": True}


def get_supervisor_for_peer(peer_name):
    info = get_peer_info(peer_name)
    if info:
        return info.get("监察员")
    return None


def get_vps_code():
    return os.environ.get("VPS_CODE", "").strip()


def get_operator_name():
    return os.environ.get("OPERATOR_NAME", "").strip()


def get_supervisor_label():
    """『麦小麦1』 标签"""
    op = get_operator_name()
    num = os.environ.get("VPS_NUM", "").strip()
    if op and num:
        return f"{op}{num}"
    code = get_vps_code()
    if code:
        import re
        m = re.search(r"(\D+?)-?(\d+)", code)
        if m:
            return f"{m.group(1)}{m.group(2)}"
    return op or "未知"


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    print("=== 配置检查 ===")
    print(f"VPS_CODE: {get_vps_code() or '(未设置)'}")
    print(f"OPERATOR_NAME: {get_operator_name() or '(未设置)'}")
    print(f"监察人员标签: {get_supervisor_label()}")
    print(f"默认群: {get_default_group()}")
    print(f"\n怠工群:")
    for k, v in get_center_groups(risk=False).items():
        status = "✅" if v else "❌未配置"
        print(f"  {k}: {v} {status}")
    print(f"\n风控群:")
    for k, v in get_center_groups(risk=True).items():
        status = "✅" if v else "❌未配置"
        print(f"  {k}: {v} {status}")

    cache = load_cache()
    if cache:
        print(f"\n=== 缓存 ===")
        print(f"  总外事号: {len(cache.get('mapping', {}))}")

    print(f"\n=== 路由测试 ===")
    for peer in ["悦悦-【官方收量】", "小橘", "彼岸花666", "不存在的号"]:
        gid_d, info_d = route_to_group(peer, risk=False)
        gid_r, _ = route_to_group(peer, risk=True)
        matched = "✅" if info_d.get("matched") else "❌"
        center = info_d.get("中心", "未知")
        print(f"  {matched} 「{peer}」→ {center} / 怠工={gid_d} / 风控={gid_r}")
