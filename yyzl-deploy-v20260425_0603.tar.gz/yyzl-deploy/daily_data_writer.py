"""每日数据写入 Google Sheets — v3
定时任务: 柬埔寨时间 周一至五 20:30 / 周六 17:30 / 周日跳过
写入位置: Sheet ID=DAILY_SHEET_ID, Tab gid=DAILY_SHEET_GID
列: F=新增 G=活跃 H=超时未查看 I=已读未回复
"""
import os
import logging
import sqlite3
from datetime import datetime, timedelta, timezone

import gspread
import oauth_helper

TZ_KH = timezone(timedelta(hours=7))
logger = logging.getLogger(__name__)

# 有效对话判定阈值 (方案B: 对方>=2 AND 我方>=2)
ACTIVE_PEER_MIN = 2
ACTIVE_ME_MIN = 2
# 活跃 vs 新增 的分水岭: 上次对话距今 < N 天 = 活跃, 否则 = 新增
ACTIVE_WINDOW_DAYS = 4


def _today_kh_range():
    """返回柬埔寨今天 0 点到 24 点的 UTC 时间戳范围"""
    now = datetime.now(TZ_KH)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=1)
    return start.timestamp(), end.timestamp()


def _get_db_path():
    """获取数据库路径 (容器内)"""
    return "/app/data/data.db"


def _stats_for_peer(conn, account_id, peer_id, today_start, today_end):
    """统计单个 peer 今天的情况, 返回 (is_active_today, is_new, is_active)
    - is_active_today: 今天双方来回 >=2 句 (对方>=2 AND 我方>=2)
    - is_new: 今天有效对话 且 (从未对话过 或 上次对话 >= 4 天前)
    - is_active: 今天有效对话 且 上次对话 < 4 天
    """
    cur = conn.cursor()
    # 今天对方发了多少句
    cur.execute(
        "SELECT COUNT(*) FROM messages WHERE account_id=? AND peer_id=? "
        "AND direction='B' AND timestamp>=? AND timestamp<?",
        (account_id, peer_id, today_start, today_end)
    )
    peer_today = cur.fetchone()[0]

    # 今天我方发了多少句
    cur.execute(
        "SELECT COUNT(*) FROM messages WHERE account_id=? AND peer_id=? "
        "AND direction='A' AND timestamp>=? AND timestamp<?",
        (account_id, peer_id, today_start, today_end)
    )
    me_today = cur.fetchone()[0]

    if peer_today < ACTIVE_PEER_MIN or me_today < ACTIVE_ME_MIN:
        return (False, False, False)

    # 是否"新增" — 查今天之前最近一次双方交互的时间
    cutoff = today_start - ACTIVE_WINDOW_DAYS * 86400
    cur.execute(
        "SELECT MAX(timestamp) FROM messages WHERE account_id=? AND peer_id=? "
        "AND timestamp<?",
        (account_id, peer_id, today_start)
    )
    row = cur.fetchone()
    last_ts = row[0] if row else None

    if last_ts is None or last_ts < cutoff:
        return (True, True, False)   # 新增
    else:
        return (True, False, True)   # 活跃


def _no_reply_count_today(conn, account_id, today_start_dt, today_end_dt):
    """统计今天被触发过 no_reply 预警的不同广告主数量"""
    cur = conn.cursor()
    cur.execute(
        "SELECT COUNT(DISTINCT peer_id) FROM alerts "
        "WHERE account_id=? AND type='no_reply' "
        "AND created_at>=? AND created_at<?",
        (account_id,
         today_start_dt.strftime("%Y-%m-%d %H:%M:%S"),
         today_end_dt.strftime("%Y-%m-%d %H:%M:%S"))
    )
    return cur.fetchone()[0]




def _find_worksheet_by_gid(spreadsheet, gid):
    """根据 gid 找 worksheet"""
    for ws in spreadsheet.worksheets():
        if str(ws.id) == str(gid):
            return ws
    return None


def run_daily_sync(sheet_id, sheet_gid):
    """主入口: 扫描 Sheet 所有行, 按外事号(E列)匹配本 VPS 登录的账号,
    有匹配的就统计并写 F/G/H/I, 没匹配的 skip(不动原值, 让其他 VPS 处理).
    返回: (success, message)
    """
    logger.info("[daily_sync] 开始执行每日数据写入...")

    # 1. 连接 Sheet
    try:
        creds = oauth_helper.get_credentials()
        gc = gspread.authorize(creds)
        ss = gc.open_by_key(sheet_id)
        ws = _find_worksheet_by_gid(ss, sheet_gid)
        if ws is None:
            msg = f"找不到 gid={sheet_gid} 的 Tab"
            logger.error(f"[daily_sync] {msg}")
            return (False, msg)
        logger.info(f"[daily_sync] 已连接 Tab: {ws.title}")
    except Exception as e:
        msg = f"连接 Sheet 失败: {e}"
        logger.error(f"[daily_sync] {msg}", exc_info=True)
        return (False, msg)

    # 2. 读取所有行
    try:
        all_rows = ws.get_all_values()
    except Exception as e:
        msg = f"读取 Sheet 失败: {e}"
        logger.error(f"[daily_sync] {msg}", exc_info=True)
        return (False, msg)

    if len(all_rows) < 2:
        return (False, "Sheet 没有数据行")

    # 3. 时间范围 (柬今天 0 点到 24 点)
    today_start_ts, today_end_ts = _today_kh_range()
    today_start_dt = datetime.fromtimestamp(today_start_ts, TZ_KH).replace(tzinfo=None)
    today_end_dt = datetime.fromtimestamp(today_end_ts, TZ_KH).replace(tzinfo=None)

    # 4. 读取本 VPS 所有已登录账号, 建立 name -> id 映射
    conn = sqlite3.connect(_get_db_path())
    try:
        cur = conn.cursor()
        cur.execute("SELECT id, name FROM accounts")
        name_to_account_id = {name: aid for aid, name in cur.fetchall() if name}

        if not name_to_account_id:
            return (False, "本 VPS 没有登录的账号")
        logger.info(f"[daily_sync] 本 VPS 已登录 {len(name_to_account_id)} 个账号")

        # 5. 扫描 Sheet 所有行, 按外事号(E列)匹配
        updates = []   # [(row_idx, new, active, no_reply, read_no_reply), ...]
        skipped = 0
        matched = 0

        for idx, row in enumerate(all_rows):
            if idx == 0:
                continue  # 跳过表头
            if len(row) < 5:
                continue
            ws_nickname = row[4].strip()
            if not ws_nickname:
                continue

            # 本 VPS 有没有这个名字的账号?
            if ws_nickname not in name_to_account_id:
                skipped += 1
                continue

            account_id = name_to_account_id[ws_nickname]
            matched += 1

            # 统计: 该账号今天有多少新增/活跃/超时
            cur.execute("SELECT id FROM peers WHERE account_id=?", (account_id,))
            peer_ids = [r[0] for r in cur.fetchall()]

            new_count = 0
            active_count = 0
            for pid in peer_ids:
                _, is_new, is_active = _stats_for_peer(
                    conn, account_id, pid, today_start_ts, today_end_ts
                )
                if is_new:
                    new_count += 1
                elif is_active:
                    active_count += 1

            no_reply_count = _no_reply_count_today(
                conn, account_id, today_start_dt, today_end_dt
            )

            row_index_1based = idx + 1
            updates.append((row_index_1based, new_count, active_count, no_reply_count, 0))
            logger.info(
                f"[daily_sync] 行{row_index_1based} 外事号={ws_nickname} "
                f"新增={new_count} 活跃={active_count} 超时={no_reply_count}"
            )
    finally:
        conn.close()

    logger.info(
        f"[daily_sync] 扫描完成: 匹配={matched} 跳过(其他VPS)={skipped}"
    )

    if not updates:
        return (False, "没有匹配到本 VPS 账号")

    # 6. 批量写入 F/G/H/I 列
    try:
        batch = []
        for row_idx, f, g, h, i in updates:
            # ≤0 的数字写空字符串(覆盖昨日残留),>0 才写数字
            cells = [v if (isinstance(v, int) and v > 0) else "" for v in (f, g, h, i)]
            batch.append({
                "range": f"F{row_idx}:I{row_idx}",
                "values": [cells]
            })
        ws.batch_update(batch, value_input_option="USER_ENTERED")
        logger.info(f"[daily_sync] 已写入 {len(updates)} 行")
        return (True, f"已写入 {len(updates)} 行")
    except Exception as e:
        msg = f"写入 Sheet 失败: {e}"
        logger.error(f"[daily_sync] {msg}", exc_info=True)
        return (False, msg)
